"""Fantasy-Medieval 3D Dice Roller powered by Panda3D (d2 - d100)."""

from __future__ import annotations

import math
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from direct.gui import DirectGuiGlobals as DGG
from direct.gui.DirectGui import (
    DirectButton,
    DirectCheckButton,
    DirectFrame,
    DirectLabel,
    DirectOptionMenu,
    DirectSlider,
)
from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from panda3d.core import (
    AmbientLight,
    DirectionalLight,
    DynamicTextFont,
    Filename,
    Geom,
    GeomNode,
    GeomTriangles,
    GeomVertexData,
    GeomVertexFormat,
    GeomVertexWriter,
    LineSegs,
    NodePath,
    PointLight,
    Quat,
    TextNode,
    Vec3,
    Vec4,
    WindowProperties,
    loadPrcFileData,
)

from dice_engine import (
    DIE_THEMES,
    MAX_DICE_COUNT,
    MAX_MODIFIER,
    MAX_SIDES,
    MIN_DICE_COUNT,
    MIN_MODIFIER,
    MIN_SIDES,
    PRESET_SIDES,
    AppSettings,
    DiceRoller,
    MultiRollRecord,
    assign_face_numbers,
    build_die_mesh,
    get_multi_roll_flavor_text,
)


def _hex_to_vec4(hex_color: str, alpha: float = 1.0) -> Vec4:
    h = hex_color.lstrip("#")
    return Vec4(
        int(h[0:2], 16) / 255.0,
        int(h[2:4], 16) / 255.0,
        int(h[4:6], 16) / 255.0,
        alpha,
    )


def _quat_from_two_vectors(v_from: Vec3, v_to: Vec3) -> Quat:
    u = Vec3(v_from)
    v = Vec3(v_to)
    u.normalize()
    v.normalize()
    dot = u.dot(v)
    if dot > 0.9999:
        return Quat.identQuat()
    if dot < -0.9999:
        axis = Vec3(1, 0, 0).cross(u)
        if axis.lengthSquared() < 1e-6:
            axis = Vec3(0, 1, 0).cross(u)
        axis.normalize()
        q = Quat()
        q.setFromAxisAngle(180.0, axis)
        return q
    axis = u.cross(v)
    q = Quat(1.0 + dot, axis.x, axis.y, axis.z)
    q.normalize()
    return q


class MedievalDicePandaApp(ShowBase):
    """Native 3D Panda3D application for the Fantasy-Medieval Dice Roller."""

    @staticmethod
    def _find_cyrillic_font_path() -> Optional[str]:
        import os

        windir = os.environ.get("WINDIR", "C:/Windows")
        candidates = [
            f"{windir}/Fonts/arial.ttf",
            f"{windir}/Fonts/tahoma.ttf",
            f"{windir}/Fonts/segoeui.ttf",
            f"{windir}/Fonts/verdana.ttf",
            f"{windir}/Fonts/georgia.ttf",
            f"{windir}/Fonts/times.ttf",
            f"{windir}/Fonts/calibri.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/System/Library/Fonts/Supplemental/Georgia.ttf",
            "/Library/Fonts/Arial.ttf",
        ]
        for path in candidates:
            if Path(path).is_file():
                return Filename.fromOsSpecific(path).getFullpath()
        return None

    def __init__(self) -> None:
        loadPrcFileData("", "text-encoding utf8")
        font_vfs_path = self._find_cyrillic_font_path()
        if font_vfs_path:
            loadPrcFileData("", f"text-default-font {font_vfs_path}")

        super().__init__()
        self.disableMouse()

        props = WindowProperties()
        props.setTitle("Кость Судьбы 3D - Panda3D (d2-d100)")
        props.setSize(1280, 780)
        self.win.requestProperties(props)
        self.setBackgroundColor(0.08, 0.05, 0.03, 1.0)

        TextNode.setDefaultEncoding(TextNode.EUtf8)
        self.ui_font = self._load_cyrillic_font(font_vfs_path)
        if self.ui_font is not None:
            TextNode.setDefaultFont(self.ui_font)
            DGG.setDefaultFont(self.ui_font)

        self.roller = DiceRoller()
        self.settings = AppSettings()
        self.sides = 20
        self.is_rolling = False

        # Camera orbit state (spherical around origin)
        self.cam_yaw = 0.0
        self.cam_pitch = 42.0
        self.cam_dist = 9.5
        self._dragging_cam = False
        self._last_mouse: Optional[Tuple[float, float]] = None

        # Active 3D dice data
        self.dice_nodes: List[Dict] = []
        self.current_values: List[int] = [20] * MAX_DICE_COUNT
        self.anim_elapsed = 0.0
        self.anim_total = 0.65
        self.pending_record: Optional[MultiRollRecord] = None

        self.render.setShaderAuto()
        self._setup_lights()
        self._build_3d_table()
        self._build_hud()
        self._bind_inputs()
        self._update_camera()
        self._rebuild_dice_3d(self.current_values, landed=False)

        self.taskMgr.add(self._update_task, "DiceUpdateTask")

    def _load_cyrillic_font(self, font_vfs_path: Optional[str]):
        if not font_vfs_path:
            print("[Font] Warning: no Cyrillic TTF font found on system.")
            return None
        try:
            fn = self.loader.loadFont(font_vfs_path, pixelsPerUnit=60)
            if fn is not None and fn.isValid():
                print(f"[Font] Loaded Cyrillic font: {font_vfs_path}")
                return fn
        except Exception as exc:
            print(f"[Font] Warning ({font_vfs_path}): {exc}")
        return None

    def _font_kw(self) -> Dict:
        return {"text_font": self.ui_font} if self.ui_font is not None else {}

    def _setup_lights(self) -> None:
        ambient = AmbientLight("ambient")
        ambient.setColor(Vec4(0.42, 0.36, 0.30, 1.0))
        self.render.setLight(self.render.attachNewNode(ambient))

        sun = DirectionalLight("sun")
        sun.setColor(Vec4(1.0, 0.93, 0.80, 1.0))
        sun.setShadowCaster(self.settings.show_shadow, 2048, 2048)
        sun.getLens().setFilmSize(12, 12)
        sun.getLens().setNearFar(1, 25)
        self.sun_np = self.render.attachNewNode(sun)
        self.sun_np.setPos(5, -6, 10)
        self.sun_np.lookAt(0, 0, 0)
        self.render.setLight(self.sun_np)
        self.sun_light = sun

        torch = PointLight("torch")
        torch.setColor(Vec4(1.0, 0.58, 0.24, 1.0))
        torch.setAttenuation((1.0, 0.04, 0.01))
        self.torch_np = self.render.attachNewNode(torch)
        self.torch_np.setPos(-4.5, 4.0, 3.5)
        self.render.setLight(self.torch_np)
        self.torch_light = torch

    def _build_3d_table(self) -> None:
        segs = 48
        radius = 5.4
        height = 0.45
        vformat = GeomVertexFormat.getV3n3c4()
        vdata = GeomVertexData("table", vformat, Geom.UHStatic)
        vw = GeomVertexWriter(vdata, "vertex")
        nw = GeomVertexWriter(vdata, "normal")
        cw = GeomVertexWriter(vdata, "color")

        wood_top = Vec4(0.20, 0.13, 0.08, 1.0)
        wood_rim = Vec4(0.58, 0.43, 0.14, 1.0)

        vw.addData3(0, 0, 0)
        nw.addData3(0, 0, 1)
        cw.addData4(wood_top)
        for i in range(segs):
            a = 2.0 * math.pi * i / segs
            vw.addData3(radius * math.cos(a), radius * math.sin(a), 0)
            nw.addData3(0, 0, 1)
            cw.addData4(wood_top)

        tris = GeomTriangles(Geom.UHStatic)
        for i in range(segs):
            nxt = 1 + ((i + 1) % segs)
            tris.addVertices(0, 1 + i, nxt)

        base_idx = 1 + segs
        for i in range(segs):
            a = 2.0 * math.pi * i / segs
            x, y = radius * math.cos(a), radius * math.sin(a)
            nx, ny = math.cos(a), math.sin(a)
            vw.addData3(x, y, 0.04)
            nw.addData3(nx, ny, 0)
            cw.addData4(wood_rim)
            vw.addData3(x, y, -height)
            nw.addData3(nx, ny, 0)
            cw.addData4(wood_rim)

        for i in range(segs):
            i0 = base_idx + i * 2
            i1 = base_idx + ((i + 1) % segs) * 2
            tris.addVertices(i0, i0 + 1, i1)
            tris.addVertices(i1, i0 + 1, i1 + 1)

        geom = Geom(vdata)
        geom.addPrimitive(tris)
        node = GeomNode("table_node")
        node.addGeom(geom)
        self.table_np = self.render.attachNewNode(node)

        for r in (4.5, 3.3):
            ls = LineSegs()
            ls.setColor(0.83, 0.68, 0.22, 0.7)
            ls.setThickness(2.0)
            for i in range(65):
                a = 2.0 * math.pi * i / 64.0
                pt = (r * math.cos(a), r * math.sin(a), 0.01)
                if i == 0:
                    ls.moveTo(*pt)
                else:
                    ls.drawTo(*pt)
            self.render.attachNewNode(ls.create())

    def _create_die_node(self, sides: int, win_value: int, landed: bool) -> Tuple[NodePath, Vec3]:
        verts, faces = build_die_mesh(sides)
        theme = DIE_THEMES.get(self.settings.theme_name, DIE_THEMES["Пергамент и Золото"])

        crit_success = landed and self.settings.highlight_crits and (win_value == sides)
        crit_fail = landed and self.settings.highlight_crits and (win_value == 1)

        if crit_success:
            base_col = _hex_to_vec4("#f5d76e")
            text_col = _hex_to_vec4("#4a2e00")
        elif crit_fail:
            base_col = _hex_to_vec4("#c43b3b")
            text_col = _hex_to_vec4("#fff0f0")
        else:
            base_col = _hex_to_vec4(theme["base"])
            text_col = _hex_to_vec4(theme["text"])

        edge_col = _hex_to_vec4(theme["edge"])

        face_centers_z = [sum(verts[idx][2] for idx in f) / len(f) for f in faces]
        top_face_idx = max(range(len(faces)), key=lambda i: face_centers_z[i])
        face_numbers = assign_face_numbers(len(faces), sides, win_value, top_face_idx)

        vformat = GeomVertexFormat.getV3n3c4()
        vdata = GeomVertexData("die", vformat, Geom.UHStatic)
        vw = GeomVertexWriter(vdata, "vertex")
        nw = GeomVertexWriter(vdata, "normal")
        cw = GeomVertexWriter(vdata, "color")
        tris = GeomTriangles(Geom.UHStatic)

        ls = LineSegs()
        ls.setColor(edge_col)
        ls.setThickness(float(self.settings.edge_width))

        root = NodePath(f"die_d{sides}")
        vert_cursor = 0
        top_normal = Vec3(0, 0, 1)

        for f_idx, face in enumerate(faces):
            p0 = Vec3(*verts[face[0]])
            p1 = Vec3(*verts[face[1]])
            p2 = Vec3(*verts[face[2]])
            normal = (p1 - p0).cross(p2 - p0)
            normal.normalize()
            if f_idx == top_face_idx:
                top_normal = normal

            f_col = Vec4(base_col)
            if f_idx == top_face_idx and landed:
                f_col = Vec4(
                    min(1.0, base_col.x * 1.12),
                    min(1.0, base_col.y * 1.12),
                    min(1.0, base_col.z * 1.12),
                    1.0,
                )

            for idx in face:
                v = verts[idx]
                vw.addData3(v[0], v[1], v[2])
                nw.addData3(normal)
                cw.addData4(f_col)

            for k in range(1, len(face) - 1):
                tris.addVertices(vert_cursor, vert_cursor + k, vert_cursor + k + 1)
            vert_cursor += len(face)

            if sides != 2 or f_idx < 2:
                for k in range(len(face)):
                    a = verts[face[k]]
                    b = verts[face[(k + 1) % len(face)]]
                    ls.moveTo(a[0] * 1.004, a[1] * 1.004, a[2] * 1.004)
                    ls.drawTo(b[0] * 1.004, b[1] * 1.004, b[2] * 1.004)

            if sides == 2 and f_idx >= 2:
                continue
            if self.settings.show_all_face_numbers or f_idx == top_face_idx:
                cx = sum(verts[idx][0] for idx in face) / len(face)
                cy = sum(verts[idx][1] for idx in face) / len(face)
                cz = sum(verts[idx][2] for idx in face) / len(face)
                face_center = Vec3(cx, cy, cz)

                tn = TextNode(f"face_txt_{f_idx}")
                if self.ui_font is not None:
                    tn.setFont(self.ui_font)
                tn.setText(str(face_numbers[f_idx]))
                tn.setAlign(TextNode.ACenter)
                tn.setTextColor(text_col)
                txt_np = root.attachNewNode(tn.generate())
                txt_np.setPos(face_center + normal * 0.025)

                up_vec = Vec3(0, 0, 1) if abs(normal.z) < 0.9 else Vec3(0, 1, 0)
                txt_np.lookAt(face_center - normal * 2.0, up_vec)

                face_r = min((Vec3(*verts[idx]) - face_center).length() for idx in face)
                digits = len(str(face_numbers[f_idx]))
                txt_scale = face_r * (0.55 if digits == 1 else (0.42 if digits == 2 else 0.32))
                txt_np.setScale(max(0.12, txt_scale))

        geom = Geom(vdata)
        geom.addPrimitive(tris)
        gnode = GeomNode("die_geom")
        gnode.addGeom(geom)
        root.attachNewNode(gnode)
        root.attachNewNode(ls.create())
        return root, top_normal

    def _get_rest_positions(self, count: int) -> List[Vec3]:
        z = 0.85
        if count == 1:
            return [Vec3(0, 0, z)]
        if count == 2:
            return [Vec3(-1.35, 0, z), Vec3(1.35, 0, z)]
        if count == 3:
            return [Vec3(-1.8, -0.5, z), Vec3(0, 0.8, z), Vec3(1.8, -0.5, z)]
        if count == 4:
            return [Vec3(-1.25, -1.1, z), Vec3(1.25, -1.1, z), Vec3(-1.25, 1.1, z), Vec3(1.25, 1.1, z)]
        pts = []
        for i in range(count):
            a = 2.0 * math.pi * i / count
            pts.append(Vec3(2.1 * math.cos(a), 1.7 * math.sin(a), z))
        return pts

    def _rebuild_dice_3d(self, values: List[int], landed: bool = False) -> None:
        for d in self.dice_nodes:
            d["np"].removeNode()
        self.dice_nodes.clear()

        count = self.settings.dice_count
        positions = self._get_rest_positions(count)
        scale = 0.95 if count <= 2 else (0.82 if count <= 4 else 0.72)

        for i in range(count):
            val = values[i] if i < len(values) else self.sides
            np, top_normal = self._create_die_node(self.sides, val, landed=landed)
            np.reparentTo(self.render)
            np.setScale(scale)
            np.setPos(positions[i])

            target_quat = _quat_from_two_vectors(top_normal, Vec3(0, 0, 1))
            np.setQuat(target_quat)

            self.dice_nodes.append({
                "np": np,
                "rest_pos": positions[i],
                "target_quat": target_quat,
                "spin_axis": Vec3(random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1)),
            })

    # -----------------------------------------------------------------------
    # DirectGUI Medieval HUD & Settings
    # -----------------------------------------------------------------------

    def _build_hud(self) -> None:
        fkw = self._font_kw()

        DirectLabel(
            text="КОСТЬ СУДЬБЫ 3D (Panda3D)",
            text_fg=(0.95, 0.80, 0.28, 1),
            frameColor=(0.14, 0.09, 0.05, 0.85),
            pos=(-0.22, 0, 0.92),
            scale=0.062,
            pad=(0.6, 0.25),
            **fkw,
        )

        self.settings_btn = DirectButton(
            text="Настройки",
            text_fg=(0.95, 0.82, 0.35, 1),
            frameColor=(0.24, 0.16, 0.10, 0.95),
            pos=(1.05, 0, 0.91),
            scale=0.05,
            pad=(0.45, 0.2),
            command=self._toggle_settings,
            **fkw,
        )
        self.settings_btn.setBin("fixed", 20)

        self.outcome_lbl = DirectLabel(
            text="Готов к броску • Мышь — камера, Пробел — бросок",
            text_fg=(0.95, 0.90, 0.78, 1),
            frameColor=(0.14, 0.09, 0.05, 0.78),
            pos=(-0.22, 0, -0.58),
            scale=0.044,
            pad=(0.5, 0.2),
            **fkw,
        )

        ctrl_frame = DirectFrame(
            frameColor=(0.93, 0.87, 0.75, 0.92),
            frameSize=(-1.28, 0.65, -0.96, -0.66),
            pos=(0, 0, 0),
        )

        for idx, s in enumerate(PRESET_SIDES):
            x = -1.16 + idx * 0.22
            DirectButton(
                parent=ctrl_frame,
                text=f"d{s}",
                text_fg=(0.14, 0.09, 0.05, 1),
                frameColor=(0.84, 0.76, 0.60, 1),
                pos=(x, 0, -0.72),
                scale=0.042,
                pad=(0.35, 0.18),
                command=self._set_sides,
                extraArgs=[s],
                **fkw,
            )

        self.sides_lbl = DirectLabel(
            parent=ctrl_frame,
            text=f"Граней: {self.sides}",
            text_fg=(0.14, 0.09, 0.05, 1),
            frameColor=(0, 0, 0, 0),
            pos=(-1.05, 0, -0.81),
            scale=0.04,
            **fkw,
        )
        self.sides_slider = DirectSlider(
            parent=ctrl_frame,
            range=(MIN_SIDES, MAX_SIDES),
            value=self.sides,
            pageSize=1,
            pos=(-0.56, 0, -0.805),
            scale=0.33,
            command=self._on_sides_slider,
        )

        self.count_lbl = DirectLabel(
            parent=ctrl_frame,
            text=f"Костей: {self.settings.dice_count}",
            text_fg=(0.14, 0.09, 0.05, 1),
            frameColor=(0, 0, 0, 0),
            pos=(-0.03, 0, -0.81),
            scale=0.038,
            **fkw,
        )
        DirectButton(parent=ctrl_frame, text="-", pos=(0.13, 0, -0.81), scale=0.038, command=self._delta_count, extraArgs=[-1], **fkw)
        DirectButton(parent=ctrl_frame, text="+", pos=(0.20, 0, -0.81), scale=0.038, command=self._delta_count, extraArgs=[1], **fkw)

        self.mod_hud_lbl = DirectLabel(
            parent=ctrl_frame,
            text=f"Мод: {self.settings.modifier:+d}",
            text_fg=(0.14, 0.09, 0.05, 1),
            frameColor=(0, 0, 0, 0),
            pos=(0.36, 0, -0.81),
            scale=0.038,
            **fkw,
        )
        DirectButton(parent=ctrl_frame, text="-", pos=(0.51, 0, -0.81), scale=0.038, command=self._delta_mod, extraArgs=[-1], **fkw)
        DirectButton(parent=ctrl_frame, text="+", pos=(0.58, 0, -0.81), scale=0.038, command=self._delta_mod, extraArgs=[1], **fkw)

        self.roll_btn = DirectButton(
            parent=ctrl_frame,
            text="БРОСИТЬ КОСТЬ",
            text_fg=(0.98, 0.94, 0.85, 1),
            frameColor=(0.55, 0.12, 0.12, 1),
            pos=(-0.32, 0, -0.90),
            scale=0.05,
            pad=(1.2, 0.22),
            command=self.start_roll,
            **fkw,
        )

        # Right Chronicle Panel
        chron_frame = DirectFrame(
            frameColor=(0.93, 0.87, 0.75, 0.90),
            frameSize=(0.68, 1.28, -0.96, 0.82),
            pos=(0, 0, 0),
        )
        DirectLabel(
            parent=chron_frame,
            text="Летопись бросков",
            text_fg=(0.14, 0.09, 0.05, 1),
            frameColor=(0, 0, 0, 0),
            pos=(0.98, 0, 0.75),
            scale=0.046,
            **fkw,
        )
        self.history_lbl = DirectLabel(
            parent=chron_frame,
            text="Пока нет бросков",
            text_fg=(0.20, 0.14, 0.09, 1),
            text_align=TextNode.ALeft,
            frameColor=(0.97, 0.93, 0.84, 1),
            pos=(0.71, 0, 0.65),
            scale=0.032,
            **fkw,
        )
        self.stats_lbl = DirectLabel(
            parent=chron_frame,
            text="Бросков: 0 | Ср: —",
            text_fg=(0.14, 0.09, 0.05, 1),
            frameColor=(0.85, 0.78, 0.63, 1),
            pos=(0.98, 0, -0.78),
            scale=0.033,
            pad=(0.3, 0.2),
            **fkw,
        )
        DirectButton(
            parent=chron_frame,
            text="Очистить",
            text_fg=(0.95, 0.88, 0.75, 1),
            frameColor=(0.24, 0.16, 0.10, 1),
            pos=(0.98, 0, -0.89),
            scale=0.04,
            pad=(0.5, 0.18),
            command=self._clear_history,
            **fkw,
        )

        # Settings Modal Frame (rendered on top bin, blocks background clicks)
        self.settings_panel = DirectFrame(
            frameColor=(0.93, 0.87, 0.75, 0.98),
            frameSize=(-0.72, 0.72, -0.72, 0.72),
            pos=(0, 0, 0.04),
            state=DGG.NORMAL,
        )
        self.settings_panel.setBin("fixed", 50)
        self.settings_panel.hide()
        self._build_settings_panel()

    def _build_settings_panel(self) -> None:
        p = self.settings_panel
        fkw = self._font_kw()

        DirectLabel(parent=p, text="Настройки 3D-алтаря", text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(0, 0, 0.61), scale=0.055, **fkw)

        DirectCheckButton(
            parent=p, text="Анимация броска", indicatorValue=self.settings.animate,
            pos=(-0.22, 0, 0.48), scale=0.042, command=self._on_setting_anim, **fkw,
        )
        DirectCheckButton(
            parent=p, text="Числа на всех гранях", indicatorValue=self.settings.show_all_face_numbers,
            pos=(-0.22, 0, 0.38), scale=0.042, command=self._on_setting_nums, **fkw,
        )
        DirectCheckButton(
            parent=p, text="Реальные тени (ShadowMap)", indicatorValue=self.settings.show_shadow,
            pos=(-0.22, 0, 0.28), scale=0.042, command=self._on_setting_shadows, **fkw,
        )
        DirectCheckButton(
            parent=p, text="Подсветка критов", indicatorValue=self.settings.highlight_crits,
            pos=(-0.22, 0, 0.18), scale=0.042, command=self._on_setting_crits, **fkw,
        )

        self.dur_lbl = DirectLabel(
            parent=p, text=f"Длительность: {self.settings.anim_duration_ms} мс",
            text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(-0.38, 0, 0.05), scale=0.036, **fkw,
        )
        self.dur_slider = DirectSlider(
            parent=p, range=(200, 2500), value=self.settings.anim_duration_ms, pageSize=50,
            pos=(0.24, 0, 0.05), scale=0.32, command=self._on_setting_dur,
        )

        self.spin_lbl = DirectLabel(
            parent=p, text=f"Скорость: {self.settings.spin_speed:.1f}x",
            text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(-0.38, 0, -0.06), scale=0.036, **fkw,
        )
        self.spin_slider = DirectSlider(
            parent=p, range=(0.4, 3.0), value=self.settings.spin_speed, pageSize=0.1,
            pos=(0.24, 0, -0.06), scale=0.32, command=self._on_setting_spin,
        )

        self.bounce_lbl = DirectLabel(
            parent=p, text=f"Прыжок: {self.settings.bounce_height}",
            text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(-0.38, 0, -0.17), scale=0.036, **fkw,
        )
        self.bounce_slider = DirectSlider(
            parent=p, range=(0, 40), value=self.settings.bounce_height, pageSize=2,
            pos=(0.24, 0, -0.17), scale=0.32, command=self._on_setting_bounce,
        )

        self.mod_set_lbl = DirectLabel(
            parent=p, text=f"Модификатор: {self.settings.modifier:+d}",
            text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(-0.38, 0, -0.28), scale=0.036, **fkw,
        )
        self.mod_slider = DirectSlider(
            parent=p, range=(MIN_MODIFIER, MAX_MODIFIER), value=self.settings.modifier, pageSize=1,
            pos=(0.24, 0, -0.28), scale=0.32, command=self._on_setting_mod,
        )

        DirectLabel(parent=p, text="Материал костей:", text_fg=(0.14, 0.09, 0.05, 1), frameColor=(0, 0, 0, 0), pos=(-0.38, 0, -0.40), scale=0.036, **fkw)
        opt_kw = {"text_font": self.ui_font, "item_text_font": self.ui_font} if self.ui_font is not None else {}
        DirectOptionMenu(
            parent=p,
            items=list(DIE_THEMES.keys()),
            initialitem=0,
            pos=(0.04, 0, -0.41),
            scale=0.038,
            command=self._on_setting_theme,
            **opt_kw,
        )

        DirectButton(
            parent=p, text="Закрыть", text_fg=(0.98, 0.94, 0.85, 1),
            frameColor=(0.55, 0.12, 0.12, 1), pos=(0, 0, -0.58), scale=0.048, pad=(0.8, 0.2),
            command=self._toggle_settings, **fkw,
        )

    # -----------------------------------------------------------------------
    # Events & Settings Callbacks
    # -----------------------------------------------------------------------

    def _bind_inputs(self) -> None:
        self.accept("space", self.start_roll)
        self.accept("enter", self.start_roll)
        self.accept("mouse1", self._start_cam_drag)
        self.accept("mouse1-up", self._stop_cam_drag)
        self.accept("wheel_up", self._zoom_cam, [-0.8])
        self.accept("wheel_down", self._zoom_cam, [0.8])

    def _start_cam_drag(self) -> None:
        if not self.settings_panel.isHidden():
            return
        if self.mouseWatcherNode.hasMouse():
            m = self.mouseWatcherNode.getMouse()
            # Avoid starting camera orbit when clicking on bottom HUD bar or right chronicle
            if m.getY() < -0.52 or m.getX() > 0.42:
                return
            self._dragging_cam = True
            self._last_mouse = (m.getX(), m.getY())

    def _stop_cam_drag(self) -> None:
        self._dragging_cam = False
        self._last_mouse = None

    def _zoom_cam(self, delta: float) -> None:
        self.cam_dist = max(4.5, min(16.0, self.cam_dist + delta))
        self._update_camera()

    def _update_camera(self) -> None:
        yr = math.radians(self.cam_yaw)
        pr = math.radians(self.cam_pitch)
        x = self.cam_dist * math.cos(pr) * math.sin(yr)
        y = -self.cam_dist * math.cos(pr) * math.cos(yr)
        z = self.cam_dist * math.sin(pr)
        self.camera.setPos(x, y, z)
        self.camera.lookAt(0, 0, 0.5)

    def _toggle_settings(self) -> None:
        if self.settings_panel.isHidden():
            self.settings_panel.show()
        else:
            self.settings_panel.hide()

    def _on_setting_anim(self, val: int) -> None:
        self.settings.animate = bool(val)

    def _on_setting_nums(self, val: int) -> None:
        self.settings.show_all_face_numbers = bool(val)
        if not self.is_rolling:
            self._rebuild_dice_3d(self.current_values, landed=False)

    def _on_setting_shadows(self, val: int) -> None:
        self.settings.show_shadow = bool(val)
        self.sun_light.setShadowCaster(self.settings.show_shadow, 2048, 2048)

    def _on_setting_crits(self, val: int) -> None:
        self.settings.highlight_crits = bool(val)

    def _on_setting_dur(self) -> None:
        self.settings.anim_duration_ms = int(round(self.dur_slider["value"]))
        self.dur_lbl["text"] = f"Длительность: {self.settings.anim_duration_ms} мс"

    def _on_setting_spin(self) -> None:
        self.settings.spin_speed = float(self.spin_slider["value"])
        self.spin_lbl["text"] = f"Скорость: {self.settings.spin_speed:.1f}x"

    def _on_setting_bounce(self) -> None:
        self.settings.bounce_height = int(round(self.bounce_slider["value"]))
        self.bounce_lbl["text"] = f"Прыжок: {self.settings.bounce_height}"

    def _on_setting_mod(self) -> None:
        self.settings.modifier = int(round(self.mod_slider["value"]))
        self.mod_set_lbl["text"] = f"Модификатор: {self.settings.modifier:+d}"
        self.mod_hud_lbl["text"] = f"Мод: {self.settings.modifier:+d}"

    def _on_setting_theme(self, choice: str) -> None:
        self.settings.theme_name = choice
        if not self.is_rolling:
            self._rebuild_dice_3d(self.current_values, landed=False)

    def _set_sides(self, sides: int) -> None:
        if self.is_rolling:
            return
        self.sides = max(MIN_SIDES, min(MAX_SIDES, int(sides)))
        self.sides_slider["value"] = self.sides
        self.sides_lbl["text"] = f"Граней: {self.sides}"
        self.current_values = [self.sides] * MAX_DICE_COUNT
        self._rebuild_dice_3d(self.current_values, landed=False)

    def _on_sides_slider(self) -> None:
        val = int(round(self.sides_slider["value"]))
        if val != self.sides and not self.is_rolling:
            self.sides = val
            self.sides_lbl["text"] = f"Граней: {self.sides}"
            self.current_values = [self.sides] * MAX_DICE_COUNT
            self._rebuild_dice_3d(self.current_values, landed=False)

    def _delta_count(self, delta: int) -> None:
        if self.is_rolling:
            return
        self.settings.dice_count = max(MIN_DICE_COUNT, min(MAX_DICE_COUNT, self.settings.dice_count + delta))
        self.count_lbl["text"] = f"Костей: {self.settings.dice_count}"
        self._rebuild_dice_3d(self.current_values, landed=False)

    def _delta_mod(self, delta: int) -> None:
        if self.is_rolling:
            return
        self.settings.modifier = max(MIN_MODIFIER, min(MAX_MODIFIER, self.settings.modifier + delta))
        self.mod_hud_lbl["text"] = f"Мод: {self.settings.modifier:+d}"
        self.mod_slider["value"] = self.settings.modifier
        self.mod_set_lbl["text"] = f"Модификатор: {self.settings.modifier:+d}"

    # -----------------------------------------------------------------------
    # Rolling & Frame Update
    # -----------------------------------------------------------------------

    def start_roll(self) -> None:
        if self.is_rolling or not self.settings_panel.isHidden():
            return
        rec = self.roller.roll_many(self.sides, self.settings.dice_count, self.settings.modifier)
        self.current_values[: rec.count] = list(rec.values)
        self.pending_record = rec

        self._rebuild_dice_3d(self.current_values, landed=True)

        if not self.settings.animate:
            self._finish_roll()
            return

        self.is_rolling = True
        self.anim_elapsed = 0.0
        self.anim_total = max(0.1, self.settings.anim_duration_ms / 1000.0)
        self.roll_btn["state"] = DGG.DISABLED

    def _finish_roll(self) -> None:
        self.is_rolling = False
        self.roll_btn["state"] = DGG.NORMAL
        rec = self.pending_record
        if rec is None:
            return

        title, subtitle = get_multi_roll_flavor_text(rec)
        self.outcome_lbl["text"] = f"{title} — {subtitle}"

        lines = []
        for r in reversed(self.roller.multi_history[-16:]):
            vals = ",".join(str(v) for v in r.values)
            lines.append(f"[{r.timestamp}] {r.label}: [{vals}] = {r.total}")
        self.history_lbl["text"] = "\n".join(lines) if lines else "Пока нет бросков"

        s = self.roller.stats()
        self.stats_lbl["text"] = (
            f"Бросков: {s.total_rolls} | Ср: {s.average:.2f} | Криты: {s.crit_successes}/{s.crit_fails}"
        )

    def _clear_history(self) -> None:
        self.roller.clear_history()
        self.history_lbl["text"] = "Пока нет бросков"
        self.stats_lbl["text"] = "Бросков: 0 | Среднее: —"

    def _update_task(self, task: Task) -> int:
        dt = globalClock.getDt()  # type: ignore[name-defined]

        t = task.time
        self.torch_light.setColor(Vec4(1.0, 0.56 + 0.06 * math.sin(t * 7.0), 0.24, 1.0))

        if self._dragging_cam and self.mouseWatcherNode.hasMouse():
            m = self.mouseWatcherNode.getMouse()
            if self._last_mouse is not None:
                dx = m.getX() - self._last_mouse[0]
                dy = m.getY() - self._last_mouse[1]
                self.cam_yaw -= dx * 90.0
                self.cam_pitch = max(12.0, min(82.0, self.cam_pitch - dy * 70.0))
                self._update_camera()
            self._last_mouse = (m.getX(), m.getY())

        if self.is_rolling:
            self.anim_elapsed += dt
            progress = min(1.0, self.anim_elapsed / max(0.05, self.anim_total))
            ease = 1.0 - (1.0 - progress) ** 3
            bounce_amp = max(0.0, self.settings.bounce_height / 10.0)
            bounce = abs(math.sin(progress * math.pi * 2.5)) * (1.0 - progress) * bounce_amp

            for idx, d in enumerate(self.dice_nodes):
                rp: Vec3 = d["rest_pos"]
                d["np"].setPos(rp.x, rp.y, rp.z + bounce + (1.0 - ease) * (bounce_amp * 0.55))
                angle_deg = (1.0 - ease) * 1080.0 * self.settings.spin_speed * (1.0 + idx * 0.1)
                spin_q = Quat()
                axis: Vec3 = d["spin_axis"]
                axis.normalize()
                spin_q.setFromAxisAngle(angle_deg, axis)
                d["np"].setQuat(d["target_quat"] * spin_q)

            if progress >= 1.0:
                for d in self.dice_nodes:
                    d["np"].setPos(d["rest_pos"])
                    d["np"].setQuat(d["target_quat"])
                self._finish_roll()

        return Task.cont


def main() -> None:
    app = MedievalDicePandaApp()
    app.run()


if __name__ == "__main__":
    main()
