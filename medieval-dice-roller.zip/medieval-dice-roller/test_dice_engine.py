"""Unit tests for dice_engine.py."""

import math
import random
import unittest

from dice_engine import (
    MAX_SIDES,
    MIN_SIDES,
    DiceRoller,
    build_die_mesh,
    compute_die_polygon,
    get_roll_flavor_text,
    project_point,
    rotate_point,
    shade_hex_color,
)


class TestDiceEngine(unittest.TestCase):
    def test_valid_sides_bounds(self) -> None:
        roller = DiceRoller(rng=random.Random(42))
        for sides in (MIN_SIDES, 6, 20, MAX_SIDES):
            record = roller.roll(sides)
            self.assertGreaterEqual(record.value, 1)
            self.assertLessEqual(record.value, sides)
            self.assertEqual(record.sides, sides)

    def test_invalid_sides_raise_value_error(self) -> None:
        roller = DiceRoller()
        for bad in (0, 1, -5, 101, 999, True, 6.5):
            with self.assertRaises(ValueError):
                roller.roll(bad)  # type: ignore[arg-type]

    def test_stats_and_history_clear(self) -> None:
        roller = DiceRoller(rng=random.Random(7))
        self.assertEqual(roller.stats().total_rolls, 0)

        for _ in range(15):
            roller.roll(20)

        stats = roller.stats()
        self.assertEqual(stats.total_rolls, 15)
        self.assertIsNotNone(stats.minimum)
        self.assertIsNotNone(stats.maximum)
        self.assertGreaterEqual(stats.minimum, 1)  # type: ignore[arg-type]
        self.assertLessEqual(stats.maximum, 20)  # type: ignore[arg-type]

        roller.clear_history()
        self.assertEqual(len(roller.history), 0)
        self.assertEqual(roller.stats().total_rolls, 0)

    def test_polygon_geometry_all_range(self) -> None:
        for sides in range(MIN_SIDES, MAX_SIDES + 1):
            pts = compute_die_polygon(sides, cx=100.0, cy=100.0, radius=50.0)
            self.assertGreaterEqual(len(pts), 3)
            for x, y in pts:
                self.assertIsInstance(x, float)
                self.assertIsInstance(y, float)

    def test_3d_meshes_all_range_and_outward_normals(self) -> None:
        for sides in range(MIN_SIDES, MAX_SIDES + 1):
            verts, faces = build_die_mesh(sides)
            self.assertGreaterEqual(len(verts), 4)
            self.assertGreaterEqual(len(faces), 4)
            for face in faces:
                self.assertGreaterEqual(len(face), 3)
                p0, p1, p2 = verts[face[0]], verts[face[1]], verts[face[2]]
                ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
                vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
                nx = uy * vz - uz * vy
                ny = uz * vx - ux * vz
                nz = ux * vy - uy * vx
                fcx = sum(verts[i][0] for i in face) / len(face)
                fcy = sum(verts[i][1] for i in face) / len(face)
                fcz = sum(verts[i][2] for i in face) / len(face)
                dot = nx * fcx + ny * fcy + nz * fcz
                self.assertGreater(dot, 0.0, f"Inward normal on d{sides}")

    def test_rotate_project_and_shade(self) -> None:
        pt = (1.0, 0.0, 0.0)
        rot = rotate_point(pt, 0.0, math.pi / 2.0, 0.0)
        self.assertAlmostEqual(rot[0], 0.0, places=5)
        self.assertAlmostEqual(abs(rot[2]), 1.0, places=5)

        px, py, pz = project_point((0.0, 0.0, 0.0), cx=180.0, cy=135.0, scale=74.0)
        self.assertAlmostEqual(px, 180.0)
        self.assertAlmostEqual(py, 135.0)
        self.assertAlmostEqual(pz, 0.0)

        shaded = shade_hex_color("#efe0c1", 0.5)
        self.assertTrue(shaded.startswith("#"))
        self.assertEqual(len(shaded), 7)

    def test_flavor_text_crit_flags(self) -> None:
        roller = DiceRoller(rng=random.Random(1))
        seen_success = False
        seen_fail = False
        for _ in range(50):
            rec = roller.roll(2)
            title, _ = get_roll_flavor_text(rec)
            if rec.is_crit_success:
                seen_success = True
                self.assertIn("УСПЕХ", title)
            if rec.is_crit_fail:
                seen_fail = True
                self.assertIn("ПРОВАЛ", title)
        self.assertTrue(seen_success and seen_fail)


if __name__ == "__main__":
    unittest.main()
