"""Fantasy-Medieval Dice Roller GUI (Python + Tkinter, d2 - d100)."""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import font as tkfont
from typing import Dict, List, Optional, Tuple

from dice_engine import (
    MAX_SIDES,
    MIN_SIDES,
    PRESET_SIDES,
    DiceRoller,
    RollRecord,
    compute_die_polygon,
    get_roll_flavor_text,
)

# Fantasy-Medieval Color Palette
PALETTE = {
    "oak_dark": "#1a110b",
    "oak_mid": "#2b1d13",
    "oak_light": "#3d2a1c",
    "parchment": "#efe0c1",
    "parchment_dark": "#dfd0ae",
    "parchment_border": "#8c6d46",
    "gold": "#d4af37",
    "gold_dim": "#9c7a2c",
    "crimson": "#8b1e1e",
    "crimson_hover": "#a82828",
    "crimson_dark": "#5e1111",
    "ink": "#24170e",
    "ink_muted": "#5c4632",
    "ivory": "#f7edd7",
    "crit_gold": "#b8860b",
    "crit_red": "#9e1b1b",
    "shadow": "#120b06",
}


class MedievalDiceApp:
    """Main Tkinter application for the Fantasy-Medieval Dice Roller."""

    ANIMATION_STEPS = 14
    ANIMATION_DELAY_MS = 38

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Кость Судьбы — Средневековый генератор (d2–d100)")
        self.root.configure(bg=PALETTE["oak_dark"])
        self.root.minsize(820, 620)

        self.roller = DiceRoller()
        self.sides_var = tk.IntVar(value=20)
        self.is_rolling = False
        self._anim_job: Optional[str] = None
        self._preset_buttons: Dict[int, tk.Button] = {}

        self._init_fonts()
        self._build_ui()
        self._bind_events()
        self._draw_die(sides=self.sides_var.get(), value=20, angle_deg=0.0)
        self._update_preset_highlight()

    def _init_fonts(self) -> None:
        available = set(tkfont.families())
        serif = "Georgia" if "Georgia" in available else (
            "Times New Roman" if "Times New Roman" in available else "serif"
        )
        mono = "Consolas" if "Consolas" in available else (
            "Courier New" if "Courier New" in available else "monospace"
        )

        self.font_title = (serif, 20, "bold")
        self.font_subtitle = (serif, 10, "italic")
        self.font_heading = (serif, 12, "bold")
        self.font_body = (serif, 10)
        self.font_body_bold = (serif, 10, "bold")
        self.font_die_num = (serif, 36, "bold")
        self.font_die_label = (serif, 10, "bold")
        self.font_button = (serif, 13, "bold")
        self.font_mono = (mono, 9)

    def _build_ui(self) -> None:
        outer = tk.Frame(
            self.root,
            bg=PALETTE["oak_dark"],
            padx=16,
            pady=14,
        )
        outer.pack(fill=tk.BOTH, expand=True)

        # Header Banner
        header = tk.Frame(
            outer,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=10,
        )
        header.pack(fill=tk.X, pady=(0, 12))

        tk.Label(
            header,
            text="⚔  КОСТЬ СУДЬБЫ  ⚔",
            font=self.font_title,
            fg=PALETTE["gold"],
            bg=PALETTE["oak_mid"],
        ).pack()
        tk.Label(
            header,
            text="Гильдия Прорицателей • Бросок кости от 2 до 100 граней",
            font=self.font_subtitle,
            fg=PALETTE["parchment"],
            bg=PALETTE["oak_mid"],
        ).pack(pady=(2, 0))

        # Main Two-Column Body
        body = tk.Frame(outer, bg=PALETTE["oak_dark"])
        body.pack(fill=tk.BOTH, expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        self._build_left_altar(body)
        self._build_right_chronicle(body)

    def _build_left_altar(self, parent: tk.Frame) -> None:
        left_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=16,
            pady=14,
        )
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        # Die Arena Canvas
        self.canvas_w = 340
        self.canvas_h = 260
        self.canvas = tk.Canvas(
            left_frame,
            width=self.canvas_w,
            height=self.canvas_h,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=2,
        )
        self.canvas.pack(pady=(0, 10))

        # Flavor Outcome Banner
        self.outcome_title_var = tk.StringVar(value="Готов к броску")
        self.outcome_sub_var = tk.StringVar(
            value="Выбери число граней и испытай благосклонность судьбы."
        )

        self.outcome_title_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_title_var,
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        )
        self.outcome_title_lbl.pack()

        self.outcome_sub_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_sub_var,
            font=self.font_subtitle,
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
            wraplength=420,
            justify=tk.CENTER,
        )
        self.outcome_sub_lbl.pack(pady=(2, 10))

        # Preset Dice Bar
        preset_box = tk.Frame(left_frame, bg=PALETTE["parchment"])
        preset_box.pack(fill=tk.X, pady=(0, 8))

        tk.Label(
            preset_box,
            text="Классические кости:",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(anchor="w", pady=(0, 4))

        btn_row = tk.Frame(preset_box, bg=PALETTE["parchment"])
        btn_row.pack(fill=tk.X)

        for sides in PRESET_SIDES:
            btn = tk.Button(
                btn_row,
                text=f"d{sides}",
                font=self.font_body_bold,
                width=4,
                bd=1,
                relief=tk.RAISED,
                cursor="hand2",
                command=lambda s=sides: self._select_sides(s),
            )
            btn.pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
            self._preset_buttons[sides] = btn

        # Custom Sides Slider + Spinbox (2..100)
        slider_box = tk.Frame(
            left_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        slider_box.pack(fill=tk.X, pady=(4, 12))

        top_row = tk.Frame(slider_box, bg=PALETTE["parchment_dark"])
        top_row.pack(fill=tk.X)

        tk.Label(
            top_row,
            text="Число граней (2–100):",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)

        self.spinbox = tk.Spinbox(
            top_row,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            textvariable=self.sides_var,
            width=5,
            font=self.font_body_bold,
            justify=tk.CENTER,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            command=self._on_sides_changed,
        )
        self.spinbox.pack(side=tk.RIGHT)

        self.scale = tk.Scale(
            slider_box,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            orient=tk.HORIZONTAL,
            variable=self.sides_var,
            showvalue=False,
            bg=PALETTE["parchment_dark"],
            fg=PALETTE["ink"],
            troughcolor=PALETTE["oak_light"],
            activebackground=PALETTE["crimson"],
            highlightthickness=0,
            command=lambda _val: self._on_sides_changed(),
        )
        self.scale.pack(fill=tk.X, pady=(6, 0))

        # Roll Button (Crimson Wax Seal Style)
        self.roll_btn = tk.Button(
            left_frame,
            text="✦  БРОСИТЬ КОСТЬ  ✦",
            font=self.font_button,
            bg=PALETTE["crimson"],
            fg=PALETTE["ivory"],
            activebackground=PALETTE["crimson_hover"],
            activeforeground=PALETTE["ivory"],
            relief=tk.RAISED,
            bd=3,
            padx=20,
            pady=10,
            cursor="hand2",
            command=self.start_roll,
        )
        self.roll_btn.pack(fill=tk.X)

        tk.Label(
            left_frame,
            text="Подсказка: нажмите Пробел или Enter для быстрого броска",
            font=(self.font_subtitle[0], 8, "italic"),
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
        ).pack(pady=(6, 0))

    def _build_right_chronicle(self, parent: tk.Frame) -> None:
        right_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=14,
        )
        right_frame.grid(row=0, column=1, sticky="nsew")

        tk.Label(
            right_frame,
            text="📜  Летопись бросков",
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(anchor="w", pady=(0, 8))

        # History Listbox + Scrollbar
        list_container = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_border"],
            bd=1,
            relief=tk.SUNKEN,
        )
        list_container.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.history_list = tk.Listbox(
            list_container,
            font=self.font_mono,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            selectbackground=PALETTE["gold_dim"],
            selectforeground=PALETTE["ivory"],
            activestyle="none",
            bd=0,
            yscrollcommand=scrollbar.set,
        )
        self.history_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.history_list.yview)

        # Stats Card
        stats_frame = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        stats_frame.pack(fill=tk.X, pady=(10, 8))

        self.stats_var = tk.StringVar(
            value="Бросков: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
        )
        tk.Label(
            stats_frame,
            textvariable=self.stats_var,
            font=self.font_mono,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            justify=tk.LEFT,
        ).pack(anchor="w")

        # Clear Button
        tk.Button(
            right_frame,
            text="Очистить летопись",
            font=self.font_body_bold,
            bg=PALETTE["oak_light"],
            fg=PALETTE["parchment"],
            activebackground=PALETTE["oak_mid"],
            activeforeground=PALETTE["gold"],
            relief=tk.RAISED,
            bd=2,
            cursor="hand2",
            command=self._clear_history,
        ).pack(fill=tk.X)

    def _bind_events(self) -> None:
        self.root.bind("<space>", self._on_hotkey_roll)
        self.root.bind("<Return>", self._on_hotkey_roll)
        self.spinbox.bind("<FocusOut>", lambda _e: self._sanitize_spinbox())
        self.spinbox.bind("<Return>", lambda _e: self._sanitize_spinbox())

    def _on_hotkey_roll(self, event: tk.Event) -> None:
        if event.widget is self.spinbox:
            self._sanitize_spinbox()
            return
        self.start_roll()

    def _sanitize_spinbox(self) -> int:
        try:
            val = int(self.spinbox.get())
        except (ValueError, tk.TclError):
            val = MIN_SIDES
        val = max(MIN_SIDES, min(MAX_SIDES, val))
        self.sides_var.set(val)
        self._on_sides_changed()
        return val

    def _select_sides(self, sides: int) -> None:
        if self.is_rolling:
            return
        self.sides_var.set(sides)
        self._on_sides_changed()

    def _on_sides_changed(self) -> None:
        try:
            sides = int(self.sides_var.get())
        except (ValueError, tk.TclError):
            return
        sides = max(MIN_SIDES, min(MAX_SIDES, sides))
        self._update_preset_highlight()
        if not self.is_rolling:
            self._draw_die(sides=sides, value=sides, angle_deg=0.0)

    def _update_preset_highlight(self) -> None:
        current = self.sides_var.get()
        for sides, btn in self._preset_buttons.items():
            if sides == current:
                btn.configure(
                    bg=PALETTE["gold"],
                    fg=PALETTE["oak_dark"],
                    relief=tk.SUNKEN,
                )
            else:
                btn.configure(
                    bg=PALETTE["parchment_dark"],
                    fg=PALETTE["ink"],
                    relief=tk.RAISED,
                )

    def start_roll(self) -> None:
        if self.is_rolling:
            return
        sides = self._sanitize_spinbox()
        self.is_rolling = True
        self.roll_btn.configure(state=tk.DISABLED, text="Кость катится...")
        self._animate_step(step=0, sides=sides)

    def _animate_step(self, step: int, sides: int) -> None:
        if step < self.ANIMATION_STEPS:
            progress = step / self.ANIMATION_STEPS
            decay = 1.0 - progress
            shake_x = math.sin(step * 1.9) * 14.0 * decay
            shake_y = math.cos(step * 2.3) * 8.0 * decay
            angle = step * 26.0 * decay
            preview = self.roller.preview_value(sides)

            self._draw_die(
                sides=sides,
                value=preview,
                angle_deg=angle,
                offset_x=shake_x,
                offset_y=shake_y,
                rolling=True,
            )
            self._anim_job = self.root.after(
                self.ANIMATION_DELAY_MS,
                lambda: self._animate_step(step + 1, sides),
            )
        else:
            record = self.roller.roll(sides)
            self._finish_roll(record)

    def _finish_roll(self, record: RollRecord) -> None:
        self.is_rolling = False
        self._anim_job = None
        self.roll_btn.configure(state=tk.NORMAL, text="✦  БРОСИТЬ КОСТЬ  ✦")

        self._draw_die(
            sides=record.sides,
            value=record.value,
            angle_deg=0.0,
            crit_success=record.is_crit_success,
            crit_fail=record.is_crit_fail,
        )

        title, subtitle = get_roll_flavor_text(record)
        self.outcome_title_var.set(title)
        self.outcome_sub_var.set(subtitle)

        if record.is_crit_success:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_gold"])
        elif record.is_crit_fail:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_red"])
        else:
            self.outcome_title_lbl.configure(fg=PALETTE["ink"])

        self._append_history(record)
        self._refresh_stats()

    def _draw_die(
        self,
        sides: int,
        value: int,
        angle_deg: float = 0.0,
        offset_x: float = 0.0,
        offset_y: float = 0.0,
        rolling: bool = False,
        crit_success: bool = False,
        crit_fail: bool = False,
    ) -> None:
        self.canvas.delete("all")
        cx = self.canvas_w / 2.0 + offset_x
        cy = self.canvas_h / 2.0 - 6.0 + offset_y

        # Ornate Arena Background (rune ring + corner rivets)
        self._draw_arena_decor()

        radius = 82.0
        # Drop shadow
        shadow_pts = compute_die_polygon(sides, cx + 6, cy + 8, radius, angle_deg)
        self.canvas.create_polygon(
            self._flatten(shadow_pts),
            fill=PALETTE["shadow"],
            outline="",
        )

        # Die body colors
        if crit_success:
            fill_color = "#f8e39c"
            outline_color = PALETTE["gold"]
            text_color = "#5c3d00"
        elif crit_fail:
            fill_color = "#f2c6c6"
            outline_color = PALETTE["crimson"]
            text_color = PALETTE["crimson_dark"]
        elif rolling:
            fill_color = "#e5d3b0"
            outline_color = PALETTE["gold_dim"]
            text_color = PALETTE["ink_muted"]
        else:
            fill_color = PALETTE["parchment"]
            outline_color = PALETTE["gold"]
            text_color = PALETTE["ink"]

        outer_pts = compute_die_polygon(sides, cx, cy, radius, angle_deg)
        self.canvas.create_polygon(
            self._flatten(outer_pts),
            fill=fill_color,
            outline=outline_color,
            width=3,
        )

        # Inner facet polygon for depth
        inner_pts = compute_die_polygon(sides, cx, cy, radius * 0.72, angle_deg)
        for (ox, oy), (ix, iy) in zip(outer_pts, inner_pts):
            self.canvas.create_line(
                ox, oy, ix, iy, fill=PALETTE["parchment_border"], width=1
            )
        self.canvas.create_polygon(
            self._flatten(inner_pts),
            fill="",
            outline=PALETTE["parchment_border"],
            width=1,
        )

        # Rolled number
        self.canvas.create_text(
            cx,
            cy - 2,
            text=str(value),
            font=self.font_die_num,
            fill=text_color,
        )

        # Die label badge at bottom of arena
        self.canvas.create_text(
            self.canvas_w / 2.0,
            self.canvas_h - 16,
            text=f"✦  d{sides}  ✦",
            font=self.font_die_label,
            fill=PALETTE["gold"],
        )

    def _draw_arena_decor(self) -> None:
        cx, cy = self.canvas_w / 2.0, self.canvas_h / 2.0 - 6.0
        for r, dash in ((108, (4, 6)), (118, None)):
            self.canvas.create_oval(
                cx - r,
                cy - r,
                cx + r,
                cy + r,
                outline=PALETTE["oak_light"] if dash is None else PALETTE["gold_dim"],
                width=1,
                dash=dash,
            )

        # Brass corner rivets
        pad = 12
        for rx, ry in (
            (pad, pad),
            (self.canvas_w - pad, pad),
            (pad, self.canvas_h - pad),
            (self.canvas_w - pad, self.canvas_h - pad),
        ):
            self.canvas.create_oval(
                rx - 4,
                ry - 4,
                rx + 4,
                ry + 4,
                fill=PALETTE["gold_dim"],
                outline=PALETTE["gold"],
                width=1,
            )

    @staticmethod
    def _flatten(points: List[Tuple[float, float]]) -> List[float]:
        return [coord for pt in points for coord in pt]

    def _append_history(self, record: RollRecord) -> None:
        tag = ""
        if record.is_crit_success:
            tag = " [КРИТ!]"
        elif record.is_crit_fail:
            tag = " [ПРОВАЛ]"

        idx = len(self.roller.history)
        line = f"#{idx:03d} [{record.timestamp}] {record.label:<4} -> {record.value:>3}{tag}"
        self.history_list.insert(0, line)

        if record.is_crit_success:
            self.history_list.itemconfig(0, fg=PALETTE["crit_gold"])
        elif record.is_crit_fail:
            self.history_list.itemconfig(0, fg=PALETTE["crit_red"])

    def _refresh_stats(self) -> None:
        s = self.roller.stats()
        if s.total_rolls == 0:
            self.stats_var.set(
                "Бросков: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
            )
            return
        self.stats_var.set(
            f"Бросков: {s.total_rolls}  |  Среднее: {s.average:.2f}\n"
            f"Мин: {s.minimum}  |  Макс: {s.maximum}  |  Криты (усп/прв): {s.crit_successes}/{s.crit_fails}"
        )

    def _clear_history(self) -> None:
        self.roller.clear_history()
        self.history_list.delete(0, tk.END)
        self._refresh_stats()


def main() -> None:
    root = tk.Tk()
    MedievalDiceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
