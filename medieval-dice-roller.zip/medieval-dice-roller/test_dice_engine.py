"""Unit tests for dice_engine.py."""

import random
import unittest

from dice_engine import (
    MAX_SIDES,
    MIN_SIDES,
    DiceRoller,
    compute_die_polygon,
    get_roll_flavor_text,
)


class TestDiceEngine(unittest.TestCase):
    def test_valid_sides_bounds(self) -> None:
        roller = DiceRoller(rng=random.Random(42))
        for sides in (MIN_SIDES, 6, 20, MAX_SIDES):
            record = roller.roll(sides)
            self.assertGreaterEqual(record.value, 1)
            self.assertLessEqual(record.value, sides)
            self.assertEqual(record.sides, sides)

    def test_invalid_sides_raise_value_error(self) -> None:
        roller = DiceRoller()
        for bad in (0, 1, -5, 101, 999, True, 6.5):
            with self.assertRaises(ValueError):
                roller.roll(bad)  # type: ignore[arg-type]

    def test_stats_and_history_clear(self) -> None:
        roller = DiceRoller(rng=random.Random(7))
        self.assertEqual(roller.stats().total_rolls, 0)

        for _ in range(15):
            roller.roll(20)

        stats = roller.stats()
        self.assertEqual(stats.total_rolls, 15)
        self.assertIsNotNone(stats.minimum)
        self.assertIsNotNone(stats.maximum)
        self.assertGreaterEqual(stats.minimum, 1)  # type: ignore[arg-type]
        self.assertLessEqual(stats.maximum, 20)  # type: ignore[arg-type]

        roller.clear_history()
        self.assertEqual(len(roller.history), 0)
        self.assertEqual(roller.stats().total_rolls, 0)

    def test_polygon_geometry_all_range(self) -> None:
        for sides in range(MIN_SIDES, MAX_SIDES + 1):
            pts = compute_die_polygon(sides, cx=100.0, cy=100.0, radius=50.0)
            self.assertGreaterEqual(len(pts), 3)
            for x, y in pts:
                self.assertIsInstance(x, float)
                self.assertIsInstance(y, float)

    def test_flavor_text_crit_flags(self) -> None:
        roller = DiceRoller(rng=random.Random(1))
        # Roll until we see both crit success and crit fail on d2
        seen_success = False
        seen_fail = False
        for _ in range(50):
            rec = roller.roll(2)
            title, _ = get_roll_flavor_text(rec)
            if rec.is_crit_success:
                seen_success = True
                self.assertIn("УСПЕХ", title)
            if rec.is_crit_fail:
                seen_fail = True
                self.assertIn("ПРОВАЛ", title)
        self.assertTrue(seen_success and seen_fail)


if __name__ == "__main__":
    unittest.main()
