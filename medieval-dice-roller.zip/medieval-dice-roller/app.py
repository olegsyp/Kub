"""Fantasy-Medieval 3D Dice Roller GUI (Python + Tkinter, d2 - d100)."""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import font as tkfont
from typing import Dict, List, Optional, Tuple

from dice_engine import (
    MAX_SIDES,
    MIN_SIDES,
    PRESET_SIDES,
    DiceRoller,
    RollRecord,
    Vec3,
    build_die_mesh,
    get_roll_flavor_text,
    project_point,
    rotate_point,
    shade_hex_color,
)

# Fantasy-Medieval Color Palette
PALETTE = {
    "oak_dark": "#1a110b",
    "oak_mid": "#2b1d13",
    "oak_light": "#3d2a1c",
    "parchment": "#efe0c1",
    "parchment_dark": "#dfd0ae",
    "parchment_border": "#8c6d46",
    "gold": "#d4af37",
    "gold_dim": "#9c7a2c",
    "crimson": "#8b1e1e",
    "crimson_hover": "#a82828",
    "crimson_dark": "#5e1111",
    "ink": "#24170e",
    "ink_muted": "#5c4632",
    "ivory": "#f7edd7",
    "crit_gold": "#b8860b",
    "crit_red": "#9e1b1b",
    "shadow": "#100905",
}

LIGHT_DIR: Vec3 = (-0.42, 0.58, 0.70)


def _norm3(v: Vec3) -> Vec3:
    length = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    return (v[0] / length, v[1] / length, v[2] / length) if length > 1e-9 else (0.0, 0.0, 1.0)


LIGHT_NORM = _norm3(LIGHT_DIR)


class MedievalDiceApp:
    """Main Tkinter application for the 3D Fantasy-Medieval Dice Roller."""

    ANIMATION_STEPS = 20
    ANIMATION_DELAY_MS = 32

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Кость Судьбы 3D — Средневековый генератор (d2–d100)")
        self.root.configure(bg=PALETTE["oak_dark"])
        self.root.minsize(840, 640)

        self.roller = DiceRoller()
        self.sides_var = tk.IntVar(value=20)
        self.is_rolling = False
        self._anim_job: Optional[str] = None
        self._preset_buttons: Dict[int, tk.Button] = {}

        # 3D state
        self._rx = 0.42
        self._ry = -0.35
        self._rz = 0.08
        self._current_value = 20
        self._crit_success = False
        self._crit_fail = False
        self._drag_last: Optional[Tuple[int, int]] = None

        self._init_fonts()
        self._build_ui()
        self._bind_events()
        self._draw_die_3d(sides=self.sides_var.get(), value=self._current_value)
        self._update_preset_highlight()

    def _init_fonts(self) -> None:
        available = set(tkfont.families())
        serif = "Georgia" if "Georgia" in available else (
            "Times New Roman" if "Times New Roman" in available else "serif"
        )
        mono = "Consolas" if "Consolas" in available else (
            "Courier New" if "Courier New" in available else "monospace"
        )

        self.font_title = (serif, 20, "bold")
        self.font_subtitle = (serif, 10, "italic")
        self.font_heading = (serif, 12, "bold")
        self.font_body = (serif, 10)
        self.font_body_bold = (serif, 10, "bold")
        self.font_die_num = (serif, 32, "bold")
        self.font_die_label = (serif, 10, "bold")
        self.font_button = (serif, 13, "bold")
        self.font_mono = (mono, 9)

    def _build_ui(self) -> None:
        outer = tk.Frame(
            self.root,
            bg=PALETTE["oak_dark"],
            padx=16,
            pady=14,
        )
        outer.pack(fill=tk.BOTH, expand=True)

        # Header Banner
        header = tk.Frame(
            outer,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=10,
        )
        header.pack(fill=tk.X, pady=(0, 12))

        tk.Label(
            header,
            text="⚔  КОСТЬ СУДЬБЫ 3D  ⚔",
            font=self.font_title,
            fg=PALETTE["gold"],
            bg=PALETTE["oak_mid"],
        ).pack()
        tk.Label(
            header,
            text="Гильдия Прорицателей • Объёмный бросок кости от 2 до 100 граней",
            font=self.font_subtitle,
            fg=PALETTE["parchment"],
            bg=PALETTE["oak_mid"],
        ).pack(pady=(2, 0))

        # Main Two-Column Body
        body = tk.Frame(outer, bg=PALETTE["oak_dark"])
        body.pack(fill=tk.BOTH, expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        self._build_left_altar(body)
        self._build_right_chronicle(body)

    def _build_left_altar(self, parent: tk.Frame) -> None:
        left_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=16,
            pady=14,
        )
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        # 3D Die Arena Canvas
        self.canvas_w = 360
        self.canvas_h = 270
        self.canvas = tk.Canvas(
            left_frame,
            width=self.canvas_w,
            height=self.canvas_h,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=2,
            cursor="fleur",
        )
        self.canvas.pack(pady=(0, 10))

        # Flavor Outcome Banner
        self.outcome_title_var = tk.StringVar(value="Готов к броску")
        self.outcome_sub_var = tk.StringVar(
            value="Выбери число граней и испытай благосклонность судьбы."
        )

        self.outcome_title_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_title_var,
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        )
        self.outcome_title_lbl.pack()

        self.outcome_sub_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_sub_var,
            font=self.font_subtitle,
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
            wraplength=420,
            justify=tk.CENTER,
        )
        self.outcome_sub_lbl.pack(pady=(2, 10))

        # Preset Dice Bar
        preset_box = tk.Frame(left_frame, bg=PALETTE["parchment"])
        preset_box.pack(fill=tk.X, pady=(0, 8))

        tk.Label(
            preset_box,
            text="Классические кости:",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(anchor="w", pady=(0, 4))

        btn_row = tk.Frame(preset_box, bg=PALETTE["parchment"])
        btn_row.pack(fill=tk.X)

        for sides in PRESET_SIDES:
            btn = tk.Button(
                btn_row,
                text=f"d{sides}",
                font=self.font_body_bold,
                width=4,
                bd=1,
                relief=tk.RAISED,
                cursor="hand2",
                command=lambda s=sides: self._select_sides(s),
            )
            btn.pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
            self._preset_buttons[sides] = btn

        # Custom Sides Slider + Spinbox (2..100)
        slider_box = tk.Frame(
            left_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        slider_box.pack(fill=tk.X, pady=(4, 12))

        top_row = tk.Frame(slider_box, bg=PALETTE["parchment_dark"])
        top_row.pack(fill=tk.X)

        tk.Label(
            top_row,
            text="Число граней (2–100):",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)

        self.spinbox = tk.Spinbox(
            top_row,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            textvariable=self.sides_var,
            width=5,
            font=self.font_body_bold,
            justify=tk.CENTER,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            command=self._on_sides_changed,
        )
        self.spinbox.pack(side=tk.RIGHT)

        self.scale = tk.Scale(
            slider_box,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            orient=tk.HORIZONTAL,
            variable=self.sides_var,
            showvalue=False,
            bg=PALETTE["parchment_dark"],
            fg=PALETTE["ink"],
            troughcolor=PALETTE["oak_light"],
            activebackground=PALETTE["crimson"],
            highlightthickness=0,
            command=lambda _val: self._on_sides_changed(),
        )
        self.scale.pack(fill=tk.X, pady=(6, 0))

        # Roll Button (Crimson Wax Seal Style)
        self.roll_btn = tk.Button(
            left_frame,
            text="✦  БРОСИТЬ КОСТЬ  ✦",
            font=self.font_button,
            bg=PALETTE["crimson"],
            fg=PALETTE["ivory"],
            activebackground=PALETTE["crimson_hover"],
            activeforeground=PALETTE["ivory"],
            relief=tk.RAISED,
            bd=3,
            padx=20,
            pady=10,
            cursor="hand2",
            command=self.start_roll,
        )
        self.roll_btn.pack(fill=tk.X)

        tk.Label(
            left_frame,
            text="Перетащите кость мышью для вращения в 3D • Пробел или Enter — бросок",
            font=(self.font_subtitle[0], 8, "italic"),
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
        ).pack(pady=(6, 0))

    def _build_right_chronicle(self, parent: tk.Frame) -> None:
        right_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=14,
        )
        right_frame.grid(row=0, column=1, sticky="nsew")

        tk.Label(
            right_frame,
            text="📜  Летопись бросков",
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(anchor="w", pady=(0, 8))

        list_container = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_border"],
            bd=1,
            relief=tk.SUNKEN,
        )
        list_container.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.history_list = tk.Listbox(
            list_container,
            font=self.font_mono,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            selectbackground=PALETTE["gold_dim"],
            selectforeground=PALETTE["ivory"],
            activestyle="none",
            bd=0,
            yscrollcommand=scrollbar.set,
        )
        self.history_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.history_list.yview)

        stats_frame = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        stats_frame.pack(fill=tk.X, pady=(10, 8))

        self.stats_var = tk.StringVar(
            value="Бросков: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
        )
        tk.Label(
            stats_frame,
            textvariable=self.stats_var,
            font=self.font_mono,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            justify=tk.LEFT,
        ).pack(anchor="w")

        tk.Button(
            right_frame,
            text="Очистить летопись",
            font=self.font_body_bold,
            bg=PALETTE["oak_light"],
            fg=PALETTE["parchment"],
            activebackground=PALETTE["oak_mid"],
            activeforeground=PALETTE["gold"],
            relief=tk.RAISED,
            bd=2,
            cursor="hand2",
            command=self._clear_history,
        ).pack(fill=tk.X)

    def _bind_events(self) -> None:
        self.root.bind("<space>", self._on_hotkey_roll)
        self.root.bind("<Return>", self._on_hotkey_roll)
        self.spinbox.bind("<FocusOut>", lambda _e: self._sanitize_spinbox())
        self.spinbox.bind("<Return>", lambda _e: self._sanitize_spinbox())

        # Interactive 3D orbit via mouse drag
        self.canvas.bind("<ButtonPress-1>", self._on_drag_start)
        self.canvas.bind("<B1-Motion>", self._on_drag_move)
        self.canvas.bind("<ButtonRelease-1>", self._on_drag_end)

    def _on_drag_start(self, event: tk.Event) -> None:
        if self.is_rolling:
            return
        self._drag_last = (event.x, event.y)

    def _on_drag_move(self, event: tk.Event) -> None:
        if self.is_rolling or self._drag_last is None:
            return
        dx = event.x - self._drag_last[0]
        dy = event.y - self._drag_last[1]
        self._drag_last = (event.x, event.y)
        self._ry += dx * 0.015
        self._rx += dy * 0.015
        self._draw_die_3d(
            sides=self.sides_var.get(),
            value=self._current_value,
            crit_success=self._crit_success,
            crit_fail=self._crit_fail,
        )

    def _on_drag_end(self, _event: tk.Event) -> None:
        self._drag_last = None

    def _on_hotkey_roll(self, event: tk.Event) -> None:
        if event.widget is self.spinbox:
            self._sanitize_spinbox()
            return
        self.start_roll()

    def _sanitize_spinbox(self) -> int:
        try:
            val = int(self.spinbox.get())
        except (ValueError, tk.TclError):
            val = MIN_SIDES
        val = max(MIN_SIDES, min(MAX_SIDES, val))
        self.sides_var.set(val)
        self._on_sides_changed()
        return val

    def _select_sides(self, sides: int) -> None:
        if self.is_rolling:
            return
        self.sides_var.set(sides)
        self._on_sides_changed()

    def _on_sides_changed(self) -> None:
        try:
            sides = int(self.sides_var.get())
        except (ValueError, tk.TclError):
            return
        sides = max(MIN_SIDES, min(MAX_SIDES, sides))
        self._current_value = sides
        self._crit_success = False
        self._crit_fail = False
        self._update_preset_highlight()
        if not self.is_rolling:
            self._draw_die_3d(sides=sides, value=sides)

    def _update_preset_highlight(self) -> None:
        current = self.sides_var.get()
        for sides, btn in self._preset_buttons.items():
            if sides == current:
                btn.configure(
                    bg=PALETTE["gold"],
                    fg=PALETTE["oak_dark"],
                    relief=tk.SUNKEN,
                )
            else:
                btn.configure(
                    bg=PALETTE["parchment_dark"],
                    fg=PALETTE["ink"],
                    relief=tk.RAISED,
                )

    def start_roll(self) -> None:
        if self.is_rolling:
            return
        sides = self._sanitize_spinbox()
        self.is_rolling = True
        self._crit_success = False
        self._crit_fail = False
        self.roll_btn.configure(state=tk.DISABLED, text="Кость катится в 3D...")
        self._animate_step(step=0, sides=sides)

    def _animate_step(self, step: int, sides: int) -> None:
        if step < self.ANIMATION_STEPS:
            progress = step / self.ANIMATION_STEPS
            decay = 1.0 - progress

            # Smooth 3D tumbling spin + vertical bounce arc
            self._rx += 0.42 * (0.35 + decay)
            self._ry += 0.55 * (0.35 + decay)
            self._rz += 0.24 * decay
            bounce_y = -abs(math.sin(progress * math.pi * 2.0)) * 24.0 * decay

            preview = self.roller.preview_value(sides)
            self._current_value = preview
            self._draw_die_3d(
                sides=sides,
                value=preview,
                offset_y=bounce_y,
                rolling=True,
            )
            self._anim_job = self.root.after(
                self.ANIMATION_DELAY_MS,
                lambda: self._animate_step(step + 1, sides),
            )
        else:
            record = self.roller.roll(sides)
            self._finish_roll(record)

    def _finish_roll(self, record: RollRecord) -> None:
        self.is_rolling = False
        self._anim_job = None
        self.roll_btn.configure(state=tk.NORMAL, text="✦  БРОСИТЬ КОСТЬ  ✦")

        self._current_value = record.value
        self._crit_success = record.is_crit_success
        self._crit_fail = record.is_crit_fail

        self._draw_die_3d(
            sides=record.sides,
            value=record.value,
            crit_success=record.is_crit_success,
            crit_fail=record.is_crit_fail,
        )

        title, subtitle = get_roll_flavor_text(record)
        self.outcome_title_var.set(title)
        self.outcome_sub_var.set(subtitle)

        if record.is_crit_success:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_gold"])
        elif record.is_crit_fail:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_red"])
        else:
            self.outcome_title_lbl.configure(fg=PALETTE["ink"])

        self._append_history(record)
        self._refresh_stats()

    def _draw_die_3d(
        self,
        sides: int,
        value: int,
        offset_y: float = 0.0,
        rolling: bool = False,
        crit_success: bool = False,
        crit_fail: bool = False,
    ) -> None:
        self.canvas.delete("all")
        self._draw_arena_decor()

        cx = self.canvas_w / 2.0
        cy = self.canvas_h / 2.0 - 8.0 + offset_y

        # Grounded 3D drop shadow (shrinks when die bounces higher)
        shadow_scale = max(0.65, 1.0 + offset_y / 65.0)
        sx_r = 62.0 * shadow_scale
        sy_r = 16.0 * shadow_scale
        shadow_cy = self.canvas_h / 2.0 + 76.0
        self.canvas.create_oval(
            cx - sx_r,
            shadow_cy - sy_r,
            cx + sx_r,
            shadow_cy + sy_r,
            fill=PALETTE["shadow"],
            outline="",
        )

        verts, faces = build_die_mesh(sides)
        rotated = [rotate_point(v, self._rx, self._ry, self._rz) for v in verts]
        projected = [project_point(v, cx, cy, scale=74.0) for v in rotated]

        # Base material color
        if crit_success:
            base_hex = "#f2d16b"
            edge_hex = PALETTE["gold"]
            text_color = "#4a2e00"
        elif crit_fail:
            base_hex = "#d98282"
            edge_hex = PALETTE["crimson"]
            text_color = PALETTE["crimson_dark"]
        elif rolling:
            base_hex = "#dfd0ae"
            edge_hex = PALETTE["gold_dim"]
            text_color = PALETTE["ink_muted"]
        else:
            base_hex = "#efe0c1"
            edge_hex = PALETTE["gold"]
            text_color = PALETTE["ink"]

        # Backface culling + Painter's algorithm sort
        visible_faces: List[Tuple[float, List[int], float, Tuple[float, float]]] = []
        for face in faces:
            p0, p1, p2 = rotated[face[0]], rotated[face[1]], rotated[face[2]]
            # Normal via cross product
            ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx

            # Perspective view check against face centroid -> camera at (0, 0, 3.6)
            fcx = sum(rotated[i][0] for i in face) / len(face)
            fcy = sum(rotated[i][1] for i in face) / len(face)
            fcz = sum(rotated[i][2] for i in face) / len(face)
            view_dot = nx * (-fcx) + ny * (-fcy) + nz * (3.6 - fcz)
            if view_dot <= 0:
                continue

            nn = _norm3((nx, ny, nz))
            lambert = max(0.0, nn[0] * LIGHT_NORM[0] + nn[1] * LIGHT_NORM[1] + nn[2] * LIGHT_NORM[2])
            intensity = 0.42 + 0.68 * lambert

            avg_z = fcz
            proj_cx = sum(projected[i][0] for i in face) / len(face)
            proj_cy = sum(projected[i][1] for i in face) / len(face)
            visible_faces.append((avg_z, face, intensity, (proj_cx, proj_cy)))

        # Sort back-to-front
        visible_faces.sort(key=lambda item: item[0])

        for _z, face, intensity, _center in visible_faces:
            pts = []
            for idx in face:
                pts.extend((projected[idx][0], projected[idx][1]))
            fill_col = shade_hex_color(base_hex, intensity)
            self.canvas.create_polygon(
                pts,
                fill=fill_col,
                outline=edge_hex,
                width=2,
                joinstyle=tk.ROUND,
            )

        # Place the rolled number on the most front-facing face center (or die center)
        if visible_faces:
            front_cx, front_cy = visible_faces[-1][3]
            label_x = cx * 0.45 + front_cx * 0.55
            label_y = cy * 0.45 + front_cy * 0.55
        else:
            label_x, label_y = cx, cy

        # Subtle backing glow for legibility across facet edges
        self.canvas.create_text(
            label_x + 1,
            label_y + 1,
            text=str(value),
            font=self.font_die_num,
            fill=PALETTE["ivory"],
        )
        self.canvas.create_text(
            label_x,
            label_y,
            text=str(value),
            font=self.font_die_num,
            fill=text_color,
        )

        # Die label badge at bottom of arena
        self.canvas.create_text(
            self.canvas_w / 2.0,
            self.canvas_h - 15,
            text=f"✦  d{sides} (3D)  ✦",
            font=self.font_die_label,
            fill=PALETTE["gold"],
        )

    def _draw_arena_decor(self) -> None:
        cx, cy = self.canvas_w / 2.0, self.canvas_h / 2.0 - 8.0
        for r, dash in ((110, (4, 6)), (120, None)):
            self.canvas.create_oval(
                cx - r,
                cy - r,
                cx + r,
                cy + r,
                outline=PALETTE["oak_light"] if dash is None else PALETTE["gold_dim"],
                width=1,
                dash=dash,
            )

        pad = 12
        for rx, ry in (
            (pad, pad),
            (self.canvas_w - pad, pad),
            (pad, self.canvas_h - pad),
            (self.canvas_w - pad, self.canvas_h - pad),
        ):
            self.canvas.create_oval(
                rx - 4,
                ry - 4,
                rx + 4,
                ry + 4,
                fill=PALETTE["gold_dim"],
                outline=PALETTE["gold"],
                width=1,
            )

    def _append_history(self, record: RollRecord) -> None:
        tag = ""
        if record.is_crit_success:
            tag = " [КРИТ!]"
        elif record.is_crit_fail:
            tag = " [ПРОВАЛ]"

        idx = len(self.roller.history)
        line = f"#{idx:03d} [{record.timestamp}] {record.label:<4} -> {record.value:>3}{tag}"
        self.history_list.insert(0, line)

        if record.is_crit_success:
            self.history_list.itemconfig(0, fg=PALETTE["crit_gold"])
        elif record.is_crit_fail:
            self.history_list.itemconfig(0, fg=PALETTE["crit_red"])

    def _refresh_stats(self) -> None:
        s = self.roller.stats()
        if s.total_rolls == 0:
            self.stats_var.set(
                "Бросков: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
            )
            return
        self.stats_var.set(
            f"Бросков: {s.total_rolls}  |  Среднее: {s.average:.2f}\n"
            f"Мин: {s.minimum}  |  Макс: {s.maximum}  |  Криты (усп/прв): {s.crit_successes}/{s.crit_fails}"
        )

    def _clear_history(self) -> None:
        self.roller.clear_history()
        self.history_list.delete(0, tk.END)
        self._refresh_stats()


def main() -> None:
    root = tk.Tk()
    MedievalDiceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
