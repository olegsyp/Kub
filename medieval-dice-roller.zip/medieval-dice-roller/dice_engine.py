"""Pure logic and 3D polyhedron engine for the Fantasy-Medieval Dice Roller (d2 - d100)."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Tuple

MIN_SIDES = 2
MAX_SIDES = 100
PRESET_SIDES = (2, 4, 6, 8, 10, 12, 20, 100)

Vec3 = Tuple[float, float, float]
Mesh3D = Tuple[List[Vec3], List[List[int]]]


@dataclass(frozen=True)
class RollRecord:
    """Represents a single die roll outcome."""

    sides: int
    value: int
    timestamp: str
    is_crit_success: bool
    is_crit_fail: bool

    @property
    def label(self) -> str:
        return f"d{self.sides}"


@dataclass
class RollStats:
    """Aggregated statistics for a session of rolls."""

    total_rolls: int = 0
    average: float = 0.0
    minimum: Optional[int] = None
    maximum: Optional[int] = None
    crit_successes: int = 0
    crit_fails: int = 0


class DiceRoller:
    """Handles validated die rolls (2-100 sides) and roll history."""

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._rng = rng or random.SystemRandom()
        self._history: List[RollRecord] = []

    @staticmethod
    def validate_sides(sides: int) -> int:
        if not isinstance(sides, int) or isinstance(sides, bool):
            raise ValueError(f"Количество граней должно быть целым числом, получено: {sides!r}")
        if sides < MIN_SIDES or sides > MAX_SIDES:
            raise ValueError(
                f"Количество граней должно быть от {MIN_SIDES} до {MAX_SIDES}, получено: {sides}"
            )
        return sides

    def roll(self, sides: int) -> RollRecord:
        """Roll a die with `sides` faces (2..100) and record the result."""
        sides = self.validate_sides(sides)
        value = self._rng.randint(1, sides)
        record = RollRecord(
            sides=sides,
            value=value,
            timestamp=datetime.now().strftime("%H:%M:%S"),
            is_crit_success=(value == sides),
            is_crit_fail=(value == 1),
        )
        self._history.append(record)
        return record

    def preview_value(self, sides: int) -> int:
        """Return a transient random face value for rolling animation without recording."""
        sides = self.validate_sides(sides)
        return self._rng.randint(1, sides)

    @property
    def history(self) -> List[RollRecord]:
        return list(self._history)

    def clear_history(self) -> None:
        self._history.clear()

    def stats(self) -> RollStats:
        if not self._history:
            return RollStats()
        values = [r.value for r in self._history]
        return RollStats(
            total_rolls=len(values),
            average=sum(values) / len(values),
            minimum=min(values),
            maximum=max(values),
            crit_successes=sum(1 for r in self._history if r.is_crit_success),
            crit_fails=sum(1 for r in self._history if r.is_crit_fail),
        )


# ---------------------------------------------------------------------------
# 3D Vector & Mesh Math
# ---------------------------------------------------------------------------

def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _normalize(v: Vec3) -> Vec3:
    length = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if length < 1e-9:
        return (0.0, 0.0, 1.0)
    return (v[0] / length, v[1] / length, v[2] / length)


def _normalize_vertices(verts: List[Vec3]) -> List[Vec3]:
    if not verts:
        return verts
    max_r = max(math.sqrt(x * x + y * y + z * z) for x, y, z in verts)
    if max_r < 1e-9:
        return verts
    return [(x / max_r, y / max_r, z / max_r) for x, y, z in verts]


def _ensure_outward_winding(verts: List[Vec3], faces: List[List[int]]) -> List[List[int]]:
    """Ensure every convex face has outward-pointing normal (CCW when viewed from outside)."""
    fixed: List[List[int]] = []
    for face in faces:
        if len(face) < 3:
            continue
        p0, p1, p2 = verts[face[0]], verts[face[1]], verts[face[2]]
        normal = _cross(_sub(p1, p0), _sub(p2, p0))
        cx = sum(verts[i][0] for i in face) / len(face)
        cy = sum(verts[i][1] for i in face) / len(face)
        cz = sum(verts[i][2] for i in face) / len(face)
        if _dot(normal, (cx, cy, cz)) < 0:
            fixed.append(list(reversed(face)))
        else:
            fixed.append(list(face))
    return fixed


def _build_cylinder_coin(segments: int = 18, half_h: float = 0.16) -> Mesh3D:
    verts: List[Vec3] = []
    for z in (half_h, -half_h):
        for i in range(segments):
            ang = 2.0 * math.pi * i / segments
            verts.append((math.cos(ang), math.sin(ang), z))
    faces: List[List[int]] = [
        list(range(segments)),
        list(range(segments, 2 * segments)),
    ]
    for i in range(segments):
        nxt = (i + 1) % segments
        faces.append([i, nxt, segments + nxt, segments + i])
    return _normalize_vertices(verts), _ensure_outward_winding(verts, faces)


def _build_tetrahedron() -> Mesh3D:
    verts: List[Vec3] = [
        (1.0, 1.0, 1.0),
        (1.0, -1.0, -1.0),
        (-1.0, 1.0, -1.0),
        (-1.0, -1.0, 1.0),
    ]
    faces = [
        [0, 1, 2],
        [0, 3, 1],
        [0, 2, 3],
        [1, 3, 2],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_cube() -> Mesh3D:
    verts: List[Vec3] = [
        (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1),
        (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
    ]
    faces = [
        [0, 1, 2, 3],
        [5, 4, 7, 6],
        [4, 0, 3, 7],
        [1, 5, 6, 2],
        [3, 2, 6, 7],
        [4, 5, 1, 0],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_octahedron() -> Mesh3D:
    verts: List[Vec3] = [
        (0, 0, 1), (0, 0, -1),
        (1, 0, 0), (-1, 0, 0),
        (0, 1, 0), (0, -1, 0),
    ]
    faces = [
        [0, 2, 4], [0, 4, 3], [0, 3, 5], [0, 5, 2],
        [1, 4, 2], [1, 3, 4], [1, 5, 3], [1, 2, 5],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_trapezohedron(n_sides: int = 5) -> Mesh3D:
    """Build an N-gonal trapezohedron (2*n_sides kite faces). n=5 -> authentic d10."""
    verts: List[Vec3] = []
    # 0: top apex, 1: bottom apex
    verts.append((0.0, 1.15, 0.0))
    verts.append((0.0, -1.15, 0.0))

    ring_h = 0.22
    for i in range(n_sides):
        ang = 2.0 * math.pi * i / n_sides
        verts.append((math.cos(ang), ring_h, math.sin(ang)))
    for i in range(n_sides):
        ang = 2.0 * math.pi * (i + 0.5) / n_sides
        verts.append((math.cos(ang), -ring_h, math.sin(ang)))

    faces: List[List[int]] = []
    for i in range(n_sides):
        u0 = 2 + i
        u1 = 2 + (i + 1) % n_sides
        l0 = 2 + n_sides + i
        l_prev = 2 + n_sides + (i - 1) % n_sides
        # Top kite
        faces.append([0, u0, l0, u1])
        # Bottom kite
        faces.append([1, l0, u0, l_prev])

    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_dodecahedron() -> Mesh3D:
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    inv = 1.0 / phi
    verts: List[Vec3] = [
        # (+/-1, +/-1, +/-1) -> 0..7
        (-1, -1, -1), (-1, -1, 1), (-1, 1, -1), (-1, 1, 1),
        (1, -1, -1), (1, -1, 1), (1, 1, -1), (1, 1, 1),
        # (0, +/-1/phi, +/-phi) -> 8..11
        (0, -inv, -phi), (0, -inv, phi), (0, inv, -phi), (0, inv, phi),
        # (+/-1/phi, +/-phi, 0) -> 12..15
        (-inv, -phi, 0), (-inv, phi, 0), (inv, -phi, 0), (inv, phi, 0),
        # (+/-phi, 0, +/-1/phi) -> 16..19
        (-phi, 0, -inv), (-phi, 0, inv), (phi, 0, -inv), (phi, 0, inv),
    ]
    faces = [
        [3, 11, 9, 1, 17],
        [3, 17, 16, 2, 13],
        [3, 13, 15, 7, 11],
        [7, 15, 6, 18, 19],
        [7, 19, 5, 9, 11],
        [5, 19, 18, 4, 14],
        [5, 14, 12, 1, 9],
        [1, 12, 0, 16, 17],
        [0, 12, 14, 4, 8],
        [0, 8, 10, 2, 16],
        [2, 10, 6, 15, 13],
        [4, 18, 6, 10, 8],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_icosahedron() -> Mesh3D:
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    verts: List[Vec3] = [
        (-1, phi, 0), (1, phi, 0), (-1, -phi, 0), (1, -phi, 0),
        (0, -1, phi), (0, 1, phi), (0, -1, -phi), (0, 1, -phi),
        (phi, 0, -1), (phi, 0, 1), (-phi, 0, -1), (-phi, 0, 1),
    ]
    faces = [
        [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
        [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
        [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
        [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_crystal_bipyramid(ring_sides: int) -> Mesh3D:
    """Build a faceted 3D bipyramid / gemstone for custom N-sided dice."""
    verts: List[Vec3] = [(0.0, 1.05, 0.0), (0.0, -1.05, 0.0)]
    for i in range(ring_sides):
        ang = 2.0 * math.pi * i / ring_sides
        verts.append((math.cos(ang), 0.0, math.sin(ang)))
    faces: List[List[int]] = []
    for i in range(ring_sides):
        c0 = 2 + i
        c1 = 2 + (i + 1) % ring_sides
        faces.append([0, c0, c1])
        faces.append([1, c1, c0])
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def build_die_mesh(sides: int) -> Mesh3D:
    """Return a 3D convex polyhedron mesh (vertices, faces) for the given die sides."""
    DiceRoller.validate_sides(sides)
    if sides == 2:
        return _build_cylinder_coin()
    if sides in (3, 4):
        return _build_tetrahedron()
    if sides == 6:
        return _build_cube()
    if sides == 8:
        return _build_octahedron()
    if sides in (10, 100):
        return _build_trapezohedron(5)
    if sides == 12:
        return _build_dodecahedron()
    if sides == 20:
        return _build_icosahedron()
    # Custom N: use a trapezohedron or crystal bipyramid capped so faces stay crisp
    ring = max(5, min(14, (sides + 1) // 2))
    return _build_crystal_bipyramid(ring)


def rotate_point(pt: Vec3, rx: float, ry: float, rz: float) -> Vec3:
    """Rotate a 3D point by Euler angles (radians) around X, Y, Z."""
    x, y, z = pt

    # Rotate around X
    cx, sx = math.cos(rx), math.sin(rx)
    y, z = y * cx - z * sx, y * sx + z * cx

    # Rotate around Y
    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy

    # Rotate around Z
    cz, sz = math.cos(rz), math.sin(rz)
    x, y = x * cz - y * sz, x * sz + y * cz

    return (x, y, z)


def project_point(
    pt: Vec3,
    cx: float,
    cy: float,
    scale: float,
    camera_dist: float = 3.6,
) -> Tuple[float, float, float]:
    """Perspective-project a 3D point to 2D canvas coordinates + depth."""
    x, y, z = pt
    denom = max(0.5, camera_dist - z)
    factor = (scale * camera_dist) / denom
    return (cx + x * factor, cy - y * factor, z)


def shade_hex_color(base_hex: str, intensity: float) -> str:
    """Modulate a #RRGGBB color by lighting intensity (0.25 .. 1.15)."""
    base = base_hex.lstrip("#")
    r = int(base[0:2], 16)
    g = int(base[2:4], 16)
    b = int(base[4:6], 16)
    factor = max(0.25, min(1.15, intensity))
    nr = min(255, max(0, int(r * factor)))
    ng = min(255, max(0, int(g * factor)))
    nb = min(255, max(0, int(b * factor)))
    return f"#{nr:02x}{ng:02x}{nb:02x}"


def compute_die_polygon(
    sides: int,
    cx: float,
    cy: float,
    radius: float,
    angle_offset_deg: float = 0.0,
) -> List[Tuple[float, float]]:
    """2D fallback polygon vertices for compatibility."""
    DiceRoller.validate_sides(sides)
    vertices = 24 if sides == 2 else (3 if sides in (3, 4) else (4 if sides in (6, 8) else 6))
    points: List[Tuple[float, float]] = []
    step = 360.0 / vertices
    for i in range(vertices):
        rad = math.radians(-90.0 + angle_offset_deg + i * step)
        points.append((cx + radius * math.cos(rad), cy + radius * math.sin(rad)))
    return points


def get_roll_flavor_text(record: RollRecord) -> Tuple[str, str]:
    """Return (title, subtitle) in medieval fantasy style for a roll result."""
    if record.is_crit_success:
        return (
            "КРИТИЧЕСКИЙ УСПЕХ!",
            f"Боги благоволят! Выпал максимум ({record.value}) на {record.label}.",
        )
    if record.is_crit_fail:
        return (
            "КРИТИЧЕСКИЙ ПРОВАЛ!",
            f"Тёмная фортуна отвернулась: единица на {record.label}.",
        )

    ratio = record.value / record.sides
    if ratio >= 0.75:
        return ("Славный бросок", f"Могучий результат {record.value} из {record.sides}.")
    if ratio >= 0.4:
        return ("Верная рука", f"Выпало {record.value} на {record.label}.")
    return ("Скромный жребий", f"Кость показала {record.value} на {record.label}.")
