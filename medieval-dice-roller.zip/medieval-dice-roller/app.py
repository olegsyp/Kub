"""Fantasy-Medieval 3D Dice Roller GUI (Python + Tkinter, d2 - d100)."""

from __future__ import annotations

import math
import tkinter as tk
from tkinter import font as tkfont
from typing import Dict, List, Optional, Tuple

from dice_engine import (
    DIE_THEMES,
    MAX_DICE_COUNT,
    MAX_MODIFIER,
    MAX_SIDES,
    MIN_DICE_COUNT,
    MIN_MODIFIER,
    MIN_SIDES,
    PRESET_SIDES,
    AppSettings,
    DiceRoller,
    MultiRollRecord,
    Vec3,
    assign_face_numbers,
    build_die_mesh,
    get_multi_roll_flavor_text,
    project_point,
    rotate_point,
    shade_hex_color,
)

# Fantasy-Medieval Color Palette
PALETTE = {
    "oak_dark": "#1a110b",
    "oak_mid": "#2b1d13",
    "oak_light": "#3d2a1c",
    "parchment": "#efe0c1",
    "parchment_dark": "#dfd0ae",
    "parchment_border": "#8c6d46",
    "gold": "#d4af37",
    "gold_dim": "#9c7a2c",
    "crimson": "#8b1e1e",
    "crimson_hover": "#a82828",
    "crimson_dark": "#5e1111",
    "ink": "#24170e",
    "ink_muted": "#5c4632",
    "ivory": "#f7edd7",
    "crit_gold": "#b8860b",
    "crit_red": "#9e1b1b",
    "shadow": "#100905",
}

LIGHT_DIR: Vec3 = (-0.42, 0.58, 0.70)


def _norm3(v: Vec3) -> Vec3:
    length = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    return (v[0] / length, v[1] / length, v[2] / length) if length > 1e-9 else (0.0, 0.0, 1.0)


LIGHT_NORM = _norm3(LIGHT_DIR)


class SettingsDialog(tk.Toplevel):
    """Modal medieval-styled dialog for configuring all dice, animation, and visual settings."""

    def __init__(
        self,
        parent: tk.Tk,
        app: "MedievalDiceApp",
    ) -> None:
        super().__init__(parent)
        self.app = app
        self.title("⚙ Настройки Кости Судьбы")
        self.configure(bg=PALETTE["oak_dark"])
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        s = app.settings
        self.var_sides = tk.IntVar(value=app.sides_var.get())
        self.var_count = tk.IntVar(value=s.dice_count)
        self.var_mod = tk.IntVar(value=s.modifier)
        self.var_animate = tk.BooleanVar(value=s.animate)
        self.var_duration = tk.IntVar(value=s.anim_duration_ms)
        self.var_fps = tk.IntVar(value=s.anim_fps)
        self.var_spin = tk.DoubleVar(value=s.spin_speed)
        self.var_bounce = tk.IntVar(value=s.bounce_height)
        self.var_all_nums = tk.BooleanVar(value=s.show_all_face_numbers)
        self.var_shadow = tk.BooleanVar(value=s.show_shadow)
        self.var_edge = tk.IntVar(value=s.edge_width)
        self.var_crits = tk.BooleanVar(value=s.highlight_crits)
        self.var_theme = tk.StringVar(value=s.theme_name)

        self._build_dialog()

    def _build_dialog(self) -> None:
        wrap = tk.Frame(
            self,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=16,
            pady=14,
        )
        wrap.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        tk.Label(
            wrap,
            text="⚙  НАСТРОЙКИ АЛТАРЯ И БРОСКА",
            font=self.app.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(pady=(0, 10))

        # Section 1: Roll & Dice
        sec1 = self._section(wrap, "Кости и бросок")
        self._slider_row(sec1, "Граней (2–100):", self.var_sides, MIN_SIDES, MAX_SIDES, 1)
        self._slider_row(sec1, "Костей одновременно (1–6):", self.var_count, MIN_DICE_COUNT, MAX_DICE_COUNT, 1)
        self._slider_row(sec1, "Модификатор суммы (-20..+20):", self.var_mod, MIN_MODIFIER, MAX_MODIFIER, 1)

        # Section 2: 3D Animation
        sec2 = self._section(wrap, "Анимация и 3D-физика")
        self._check_row(sec2, "Включить анимацию броска", self.var_animate)
        self._slider_row(sec2, "Длительность (мс):", self.var_duration, 100, 3000, 50)
        self._slider_row(sec2, "Частота кадров (FPS):", self.var_fps, 15, 60, 5)
        self._slider_row(sec2, "Скорость вращения (x):", self.var_spin, 0.3, 3.0, 0.1)
        self._slider_row(sec2, "Высота подпрыгивания (px):", self.var_bounce, 0, 40, 2)

        # Section 3: Visuals & Theme
        sec3 = self._section(wrap, "Отображение и стиль")
        self._check_row(sec3, "Числа на каждой грани 3D-кости", self.var_all_nums)
        self._check_row(sec3, "Отображать тень на столе", self.var_shadow)
        self._check_row(sec3, "Подсвечивать критические исходы", self.var_crits)
        self._slider_row(sec3, "Толщина рёбер (px):", self.var_edge, 1, 4, 1)

        theme_row = tk.Frame(sec3, bg=PALETTE["parchment_dark"])
        theme_row.pack(fill=tk.X, pady=(4, 2))
        tk.Label(
            theme_row,
            text="Материал костей:",
            font=self.app.font_body,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)
        menu = tk.OptionMenu(theme_row, self.var_theme, *DIE_THEMES.keys())
        menu.configure(
            font=self.app.font_body,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            highlightthickness=0,
        )
        menu.pack(side=tk.RIGHT)

        # Buttons
        btns = tk.Frame(wrap, bg=PALETTE["parchment"])
        btns.pack(fill=tk.X, pady=(12, 0))

        tk.Button(
            btns,
            text="Сбросить",
            font=self.app.font_body_bold,
            bg=PALETTE["oak_light"],
            fg=PALETTE["parchment"],
            cursor="hand2",
            command=self._reset_defaults,
        ).pack(side=tk.LEFT)

        tk.Button(
            btns,
            text="Отмена",
            font=self.app.font_body_bold,
            bg=PALETTE["parchment_dark"],
            fg=PALETTE["ink"],
            cursor="hand2",
            command=self.destroy,
        ).pack(side=tk.RIGHT, padx=(6, 0))

        tk.Button(
            btns,
            text="Применить",
            font=self.app.font_body_bold,
            bg=PALETTE["crimson"],
            fg=PALETTE["ivory"],
            cursor="hand2",
            command=self._apply,
        ).pack(side=tk.RIGHT)

    def _section(self, parent: tk.Frame, title: str) -> tk.Frame:
        box = tk.LabelFrame(
            parent,
            text=f" {title} ",
            font=self.app.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            bd=1,
            relief=tk.GROOVE,
            padx=10,
            pady=6,
        )
        box.pack(fill=tk.X, pady=(0, 8))
        return box

    def _slider_row(
        self,
        parent: tk.Frame,
        label: str,
        var: tk.Variable,
        frm: float,
        to: float,
        res: float,
    ) -> None:
        row = tk.Frame(parent, bg=PALETTE["parchment_dark"])
        row.pack(fill=tk.X, pady=2)
        tk.Label(
            row,
            text=label,
            font=self.app.font_body,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            width=26,
            anchor="w",
        ).pack(side=tk.LEFT)
        tk.Scale(
            row,
            from_=frm,
            to=to,
            resolution=res,
            orient=tk.HORIZONTAL,
            variable=var,
            length=170,
            bg=PALETTE["parchment_dark"],
            fg=PALETTE["ink"],
            troughcolor=PALETTE["oak_light"],
            activebackground=PALETTE["crimson"],
            highlightthickness=0,
        ).pack(side=tk.RIGHT, fill=tk.X, expand=True)

    def _check_row(self, parent: tk.Frame, label: str, var: tk.BooleanVar) -> None:
        tk.Checkbutton(
            parent,
            text=label,
            variable=var,
            font=self.app.font_body,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            activebackground=PALETTE["parchment_dark"],
            selectcolor=PALETTE["ivory"],
            anchor="w",
        ).pack(fill=tk.X, pady=1)

    def _reset_defaults(self) -> None:
        d = AppSettings()
        self.var_sides.set(20)
        self.var_count.set(d.dice_count)
        self.var_mod.set(d.modifier)
        self.var_animate.set(d.animate)
        self.var_duration.set(d.anim_duration_ms)
        self.var_fps.set(d.anim_fps)
        self.var_spin.set(d.spin_speed)
        self.var_bounce.set(d.bounce_height)
        self.var_all_nums.set(d.show_all_face_numbers)
        self.var_shadow.set(d.show_shadow)
        self.var_edge.set(d.edge_width)
        self.var_crits.set(d.highlight_crits)
        self.var_theme.set(d.theme_name)

    def _apply(self) -> None:
        new_settings = AppSettings(
            dice_count=self.var_count.get(),
            modifier=self.var_mod.get(),
            animate=self.var_animate.get(),
            anim_duration_ms=self.var_duration.get(),
            anim_fps=self.var_fps.get(),
            spin_speed=self.var_spin.get(),
            bounce_height=self.var_bounce.get(),
            show_all_face_numbers=self.var_all_nums.get(),
            show_shadow=self.var_shadow.get(),
            edge_width=self.var_edge.get(),
            highlight_crits=self.var_crits.get(),
            theme_name=self.var_theme.get(),
        ).normalized()
        self.app.apply_settings(new_settings, sides=self.var_sides.get())
        self.destroy()


class MedievalDiceApp:
    """Main Tkinter application for the 3D Fantasy-Medieval Dice Roller."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Кость Судьбы 3D — Средневековый генератор (d2–d100)")
        self.root.configure(bg=PALETTE["oak_dark"])
        self.root.minsize(880, 680)

        self.roller = DiceRoller()
        self.settings = AppSettings()
        self.sides_var = tk.IntVar(value=20)
        self.count_var = tk.IntVar(value=self.settings.dice_count)
        self.mod_var = tk.IntVar(value=self.settings.modifier)

        self.is_rolling = False
        self._anim_job: Optional[str] = None
        self._preset_buttons: Dict[int, tk.Button] = {}

        # Per-die 3D state for 1..6 simultaneous dice
        self._dice_rotations: List[List[float]] = [
            [0.42 + i * 0.25, -0.35 + i * 0.3, 0.08 + i * 0.15]
            for i in range(MAX_DICE_COUNT)
        ]
        self._current_values: List[int] = [20] * MAX_DICE_COUNT
        self._drag_last: Optional[Tuple[int, int]] = None

        self._init_fonts()
        self._build_ui()
        self._bind_events()
        self._draw_scene()
        self._update_preset_highlight()

    def _init_fonts(self) -> None:
        available = set(tkfont.families())
        self._serif = "Georgia" if "Georgia" in available else (
            "Times New Roman" if "Times New Roman" in available else "serif"
        )
        mono = "Consolas" if "Consolas" in available else (
            "Courier New" if "Courier New" in available else "monospace"
        )

        self.font_title = (self._serif, 20, "bold")
        self.font_subtitle = (self._serif, 10, "italic")
        self.font_heading = (self._serif, 12, "bold")
        self.font_body = (self._serif, 10)
        self.font_body_bold = (self._serif, 10, "bold")
        self.font_die_label = (self._serif, 10, "bold")
        self.font_button = (self._serif, 13, "bold")
        self.font_mono = (mono, 9)

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=PALETTE["oak_dark"], padx=16, pady=14)
        outer.pack(fill=tk.BOTH, expand=True)

        # Header Banner
        header = tk.Frame(
            outer,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=10,
        )
        header.pack(fill=tk.X, pady=(0, 12))

        header_top = tk.Frame(header, bg=PALETTE["oak_mid"])
        header_top.pack(fill=tk.X)

        tk.Label(
            header_top,
            text="⚔  КОСТЬ СУДЬБЫ 3D  ⚔",
            font=self.font_title,
            fg=PALETTE["gold"],
            bg=PALETTE["oak_mid"],
        ).pack(side=tk.LEFT, expand=True)

        tk.Button(
            header_top,
            text="⚙ Настройки",
            font=self.font_body_bold,
            bg=PALETTE["oak_light"],
            fg=PALETTE["gold"],
            activebackground=PALETTE["gold_dim"],
            activeforeground=PALETTE["oak_dark"],
            relief=tk.RAISED,
            bd=2,
            cursor="hand2",
            command=self._open_settings,
        ).pack(side=tk.RIGHT)

        tk.Label(
            header,
            text="Гильдия Прорицателей • Объёмный бросок 1–6 костей от 2 до 100 граней",
            font=self.font_subtitle,
            fg=PALETTE["parchment"],
            bg=PALETTE["oak_mid"],
        ).pack(pady=(2, 0))

        # Main Two-Column Body
        body = tk.Frame(outer, bg=PALETTE["oak_dark"])
        body.pack(fill=tk.BOTH, expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        self._build_left_altar(body)
        self._build_right_chronicle(body)

    def _build_left_altar(self, parent: tk.Frame) -> None:
        left_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=16,
            pady=14,
        )
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        # 3D Die Arena Canvas
        self.canvas_w = 420
        self.canvas_h = 280
        self.canvas = tk.Canvas(
            left_frame,
            width=self.canvas_w,
            height=self.canvas_h,
            bg=PALETTE["oak_mid"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=2,
            cursor="fleur",
        )
        self.canvas.pack(pady=(0, 10))

        # Flavor Outcome Banner
        self.outcome_title_var = tk.StringVar(value="Готов к броску")
        self.outcome_sub_var = tk.StringVar(
            value="Выбери грани, количество костей и испытай благосклонность судьбы."
        )

        self.outcome_title_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_title_var,
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        )
        self.outcome_title_lbl.pack()

        self.outcome_sub_lbl = tk.Label(
            left_frame,
            textvariable=self.outcome_sub_var,
            font=self.font_subtitle,
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
            wraplength=440,
            justify=tk.CENTER,
        )
        self.outcome_sub_lbl.pack(pady=(2, 8))

        # Preset Dice Bar
        preset_box = tk.Frame(left_frame, bg=PALETTE["parchment"])
        preset_box.pack(fill=tk.X, pady=(0, 8))

        btn_row = tk.Frame(preset_box, bg=PALETTE["parchment"])
        btn_row.pack(fill=tk.X)

        for sides in PRESET_SIDES:
            btn = tk.Button(
                btn_row,
                text=f"d{sides}",
                font=self.font_body_bold,
                width=4,
                bd=1,
                relief=tk.RAISED,
                cursor="hand2",
                command=lambda s=sides: self._select_sides(s),
            )
            btn.pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
            self._preset_buttons[sides] = btn

        # Quick Controls Box: Sides (2-100), Count (1-6), Modifier (-20..+20)
        ctrl_box = tk.Frame(
            left_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        ctrl_box.pack(fill=tk.X, pady=(2, 10))

        top_row = tk.Frame(ctrl_box, bg=PALETTE["parchment_dark"])
        top_row.pack(fill=tk.X)

        tk.Label(
            top_row,
            text="Граней (2–100):",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)

        self.spinbox = tk.Spinbox(
            top_row,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            textvariable=self.sides_var,
            width=4,
            font=self.font_body_bold,
            justify=tk.CENTER,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            command=self._on_sides_changed,
        )
        self.spinbox.pack(side=tk.LEFT, padx=(4, 14))

        tk.Label(
            top_row,
            text="Костей (1–6):",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)

        self.count_spin = tk.Spinbox(
            top_row,
            from_=MIN_DICE_COUNT,
            to=MAX_DICE_COUNT,
            textvariable=self.count_var,
            width=3,
            font=self.font_body_bold,
            justify=tk.CENTER,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            command=self._on_quick_count_changed,
        )
        self.count_spin.pack(side=tk.LEFT, padx=(4, 14))

        tk.Label(
            top_row,
            text="Мод.:",
            font=self.font_body_bold,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
        ).pack(side=tk.LEFT)

        self.mod_spin = tk.Spinbox(
            top_row,
            from_=MIN_MODIFIER,
            to=MAX_MODIFIER,
            textvariable=self.mod_var,
            width=4,
            font=self.font_body_bold,
            justify=tk.CENTER,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            command=self._on_quick_mod_changed,
        )
        self.mod_spin.pack(side=tk.LEFT, padx=(4, 0))

        self.scale = tk.Scale(
            ctrl_box,
            from_=MIN_SIDES,
            to=MAX_SIDES,
            orient=tk.HORIZONTAL,
            variable=self.sides_var,
            showvalue=False,
            bg=PALETTE["parchment_dark"],
            fg=PALETTE["ink"],
            troughcolor=PALETTE["oak_light"],
            activebackground=PALETTE["crimson"],
            highlightthickness=0,
            command=lambda _val: self._on_sides_changed(),
        )
        self.scale.pack(fill=tk.X, pady=(6, 0))

        # Roll Button
        self.roll_btn = tk.Button(
            left_frame,
            text="✦  БРОСИТЬ КОСТЬ  ✦",
            font=self.font_button,
            bg=PALETTE["crimson"],
            fg=PALETTE["ivory"],
            activebackground=PALETTE["crimson_hover"],
            activeforeground=PALETTE["ivory"],
            relief=tk.RAISED,
            bd=3,
            padx=20,
            pady=10,
            cursor="hand2",
            command=self.start_roll,
        )
        self.roll_btn.pack(fill=tk.X)

        tk.Label(
            left_frame,
            text="Мышь — вращать кости в 3D • Пробел/Enter — бросок • ⚙ Настройки — анимация и тема",
            font=(self._serif, 8, "italic"),
            fg=PALETTE["ink_muted"],
            bg=PALETTE["parchment"],
        ).pack(pady=(6, 0))

    def _build_right_chronicle(self, parent: tk.Frame) -> None:
        right_frame = tk.Frame(
            parent,
            bg=PALETTE["parchment"],
            highlightbackground=PALETTE["gold_dim"],
            highlightthickness=2,
            padx=14,
            pady=14,
        )
        right_frame.grid(row=0, column=1, sticky="nsew")

        tk.Label(
            right_frame,
            text="📜  Летопись бросков",
            font=self.font_heading,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment"],
        ).pack(anchor="w", pady=(0, 8))

        list_container = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_border"],
            bd=1,
            relief=tk.SUNKEN,
        )
        list_container.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_container)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.history_list = tk.Listbox(
            list_container,
            font=self.font_mono,
            bg=PALETTE["ivory"],
            fg=PALETTE["ink"],
            selectbackground=PALETTE["gold_dim"],
            selectforeground=PALETTE["ivory"],
            activestyle="none",
            bd=0,
            yscrollcommand=scrollbar.set,
        )
        self.history_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.history_list.yview)

        stats_frame = tk.Frame(
            right_frame,
            bg=PALETTE["parchment_dark"],
            highlightbackground=PALETTE["parchment_border"],
            highlightthickness=1,
            padx=10,
            pady=8,
        )
        stats_frame.pack(fill=tk.X, pady=(10, 8))

        self.stats_var = tk.StringVar(
            value="Костей брошено: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
        )
        tk.Label(
            stats_frame,
            textvariable=self.stats_var,
            font=self.font_mono,
            fg=PALETTE["ink"],
            bg=PALETTE["parchment_dark"],
            justify=tk.LEFT,
        ).pack(anchor="w")

        tk.Button(
            right_frame,
            text="Очистить летопись",
            font=self.font_body_bold,
            bg=PALETTE["oak_light"],
            fg=PALETTE["parchment"],
            activebackground=PALETTE["oak_mid"],
            activeforeground=PALETTE["gold"],
            relief=tk.RAISED,
            bd=2,
            cursor="hand2",
            command=self._clear_history,
        ).pack(fill=tk.X)

    def _bind_events(self) -> None:
        self.root.bind("<space>", self._on_hotkey_roll)
        self.root.bind("<Return>", self._on_hotkey_roll)
        for widget, handler in (
            (self.spinbox, lambda _e: self._sanitize_spinbox()),
            (self.count_spin, lambda _e: self._on_quick_count_changed()),
            (self.mod_spin, lambda _e: self._on_quick_mod_changed()),
        ):
            widget.bind("<FocusOut>", handler)
            widget.bind("<Return>", handler)

        self.canvas.bind("<ButtonPress-1>", self._on_drag_start)
        self.canvas.bind("<B1-Motion>", self._on_drag_move)
        self.canvas.bind("<ButtonRelease-1>", self._on_drag_end)

    def _open_settings(self) -> None:
        if self.is_rolling:
            return
        SettingsDialog(self.root, self)

    def apply_settings(self, new_settings: AppSettings, sides: Optional[int] = None) -> None:
        self.settings = new_settings.normalized()
        self.count_var.set(self.settings.dice_count)
        self.mod_var.set(self.settings.modifier)
        if sides is not None:
            clamped = max(MIN_SIDES, min(MAX_SIDES, int(sides)))
            self.sides_var.set(clamped)
            self._current_values = [clamped] * MAX_DICE_COUNT
        self._update_preset_highlight()
        self._update_roll_button_label()
        self._draw_scene()

    def _update_roll_button_label(self) -> None:
        if self.is_rolling:
            return
        if self.settings.dice_count == 1:
            self.roll_btn.configure(text="✦  БРОСИТЬ КОСТЬ  ✦")
        else:
            self.roll_btn.configure(text=f"✦  БРОСИТЬ {self.settings.dice_count} КОСТИ  ✦")

    def _on_drag_start(self, event: tk.Event) -> None:
        if self.is_rolling:
            return
        self._drag_last = (event.x, event.y)

    def _on_drag_move(self, event: tk.Event) -> None:
        if self.is_rolling or self._drag_last is None:
            return
        dx = event.x - self._drag_last[0]
        dy = event.y - self._drag_last[1]
        self._drag_last = (event.x, event.y)
        for rot in self._dice_rotations:
            rot[1] += dx * 0.015
            rot[0] += dy * 0.015
        self._draw_scene()

    def _on_drag_end(self, _event: tk.Event) -> None:
        self._drag_last = None

    def _on_hotkey_roll(self, event: tk.Event) -> None:
        if event.widget in (self.spinbox, self.count_spin, self.mod_spin):
            self._sanitize_spinbox()
            self._on_quick_count_changed()
            self._on_quick_mod_changed()
            return
        self.start_roll()

    def _sanitize_spinbox(self) -> int:
        try:
            val = int(self.spinbox.get())
        except (ValueError, tk.TclError):
            val = MIN_SIDES
        val = max(MIN_SIDES, min(MAX_SIDES, val))
        self.sides_var.set(val)
        self._on_sides_changed()
        return val

    def _on_quick_count_changed(self) -> None:
        try:
            val = int(self.count_spin.get())
        except (ValueError, tk.TclError):
            val = MIN_DICE_COUNT
        val = max(MIN_DICE_COUNT, min(MAX_DICE_COUNT, val))
        self.count_var.set(val)
        self.settings.dice_count = val
        self._update_roll_button_label()
        if not self.is_rolling:
            self._draw_scene()

    def _on_quick_mod_changed(self) -> None:
        try:
            val = int(self.mod_spin.get())
        except (ValueError, tk.TclError):
            val = 0
        val = max(MIN_MODIFIER, min(MAX_MODIFIER, val))
        self.mod_var.set(val)
        self.settings.modifier = val

    def _select_sides(self, sides: int) -> None:
        if self.is_rolling:
            return
        self.sides_var.set(sides)
        self._on_sides_changed()

    def _on_sides_changed(self) -> None:
        try:
            sides = int(self.sides_var.get())
        except (ValueError, tk.TclError):
            return
        sides = max(MIN_SIDES, min(MAX_SIDES, sides))
        self._current_values = [sides] * MAX_DICE_COUNT
        self._update_preset_highlight()
        if not self.is_rolling:
            self._draw_scene()

    def _update_preset_highlight(self) -> None:
        current = self.sides_var.get()
        for sides, btn in self._preset_buttons.items():
            if sides == current:
                btn.configure(bg=PALETTE["gold"], fg=PALETTE["oak_dark"], relief=tk.SUNKEN)
            else:
                btn.configure(bg=PALETTE["parchment_dark"], fg=PALETTE["ink"], relief=tk.RAISED)

    def start_roll(self) -> None:
        if self.is_rolling:
            return
        sides = self._sanitize_spinbox()
        self._on_quick_count_changed()
        self._on_quick_mod_changed()

        if not self.settings.animate:
            record = self.roller.roll_many(sides, self.settings.dice_count, self.settings.modifier)
            self._finish_roll(record)
            return

        self.is_rolling = True
        self.roll_btn.configure(state=tk.DISABLED, text="Кости катятся в 3D...")

        delay_ms = max(16, int(1000 / self.settings.anim_fps))
        total_steps = max(3, int(self.settings.anim_duration_ms / delay_ms))
        self._animate_step(step=0, total_steps=total_steps, delay_ms=delay_ms, sides=sides)

    def _animate_step(self, step: int, total_steps: int, delay_ms: int, sides: int) -> None:
        if step < total_steps:
            progress = step / total_steps
            decay = 1.0 - progress
            spd = self.settings.spin_speed

            offsets_y: List[float] = []
            for i in range(self.settings.dice_count):
                rot = self._dice_rotations[i]
                rot[0] += (0.38 + i * 0.05) * spd * (0.3 + decay)
                rot[1] += (0.52 + i * 0.06) * spd * (0.3 + decay)
                rot[2] += 0.22 * spd * decay
                phase = progress * math.pi * 2.0 + i * 0.45
                offsets_y.append(-abs(math.sin(phase)) * self.settings.bounce_height * decay)
                self._current_values[i] = self.roller.preview_value(sides)

            self._draw_scene(offsets_y=offsets_y, rolling=True)
            self._anim_job = self.root.after(
                delay_ms,
                lambda: self._animate_step(step + 1, total_steps, delay_ms, sides),
            )
        else:
            record = self.roller.roll_many(sides, self.settings.dice_count, self.settings.modifier)
            self._finish_roll(record)

    def _finish_roll(self, record: MultiRollRecord) -> None:
        self.is_rolling = False
        self._anim_job = None
        self._update_roll_button_label()
        self.roll_btn.configure(state=tk.NORMAL)

        for i, val in enumerate(record.values):
            self._current_values[i] = val

        self._draw_scene(rolling=False, landed=True)

        title, subtitle = get_multi_roll_flavor_text(record)
        self.outcome_title_var.set(title)
        self.outcome_sub_var.set(subtitle)

        if self.settings.highlight_crits and record.crit_successes > 0 and record.crit_fails == 0:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_gold"])
        elif self.settings.highlight_crits and record.crit_fails > 0 and record.crit_successes == 0:
            self.outcome_title_lbl.configure(fg=PALETTE["crit_red"])
        else:
            self.outcome_title_lbl.configure(fg=PALETTE["ink"])

        self._append_history(record)
        self._refresh_stats()

    def _grid_layout(self, count: int) -> Tuple[List[Tuple[float, float]], float]:
        """Return center (x, y) positions and 3D scale for 1..6 dice."""
        w, h = self.canvas_w, self.canvas_h - 18
        if count == 1:
            return [(w / 2.0, h / 2.0)], 74.0
        if count == 2:
            return [(w * 0.30, h / 2.0), (w * 0.70, h / 2.0)], 56.0
        if count == 3:
            return [(w * 0.20, h / 2.0), (w * 0.50, h / 2.0), (w * 0.80, h / 2.0)], 46.0
        if count == 4:
            return [
                (w * 0.32, h * 0.29), (w * 0.68, h * 0.29),
                (w * 0.32, h * 0.71), (w * 0.68, h * 0.71),
            ], 42.0
        if count == 5:
            return [
                (w * 0.22, h * 0.29), (w * 0.50, h * 0.29), (w * 0.78, h * 0.29),
                (w * 0.35, h * 0.71), (w * 0.65, h * 0.71),
            ], 38.0
        return [
            (w * 0.22, h * 0.29), (w * 0.50, h * 0.29), (w * 0.78, h * 0.29),
            (w * 0.22, h * 0.71), (w * 0.50, h * 0.71), (w * 0.78, h * 0.71),
        ], 38.0

    def _draw_scene(
        self,
        offsets_y: Optional[List[float]] = None,
        rolling: bool = False,
        landed: bool = False,
    ) -> None:
        self.canvas.delete("all")
        self._draw_arena_decor()

        sides = max(MIN_SIDES, min(MAX_SIDES, int(self.sides_var.get())))
        count = self.settings.dice_count
        positions, scale = self._grid_layout(count)
        verts, faces = build_die_mesh(sides)

        for i in range(count):
            cx, base_cy = positions[i]
            oy = offsets_y[i] if offsets_y and i < len(offsets_y) else 0.0
            self._draw_single_die_3d(
                sides=sides,
                value=self._current_values[i],
                verts=verts,
                faces=faces,
                rot=self._dice_rotations[i],
                cx=cx,
                base_cy=base_cy,
                offset_y=oy,
                scale=scale,
                rolling=rolling,
                landed=landed,
            )

        mod_str = f" {self.settings.modifier:+d}" if self.settings.modifier != 0 else ""
        prefix = f"{count}" if count > 1 else ""
        self.canvas.create_text(
            self.canvas_w / 2.0,
            self.canvas_h - 13,
            text=f"✦  {prefix}d{sides}{mod_str} (3D)  ✦",
            font=self.font_die_label,
            fill=PALETTE["gold"],
        )

    def _draw_single_die_3d(
        self,
        sides: int,
        value: int,
        verts: List[Vec3],
        faces: List[List[int]],
        rot: List[float],
        cx: float,
        base_cy: float,
        offset_y: float,
        scale: float,
        rolling: bool,
        landed: bool,
    ) -> None:
        cy = base_cy + offset_y

        if self.settings.show_shadow:
            shadow_scale = max(0.65, 1.0 + offset_y / 65.0)
            sx_r = scale * 0.82 * shadow_scale
            sy_r = scale * 0.22 * shadow_scale
            shadow_cy = base_cy + scale * 1.02
            self.canvas.create_oval(
                cx - sx_r, shadow_cy - sy_r, cx + sx_r, shadow_cy + sy_r,
                fill=PALETTE["shadow"], outline="",
            )

        rotated = [rotate_point(v, rot[0], rot[1], rot[2]) for v in verts]
        projected = [project_point(v, cx, cy, scale=scale) for v in rotated]

        theme = DIE_THEMES.get(self.settings.theme_name, DIE_THEMES["Пергамент и Золото"])
        crit_success = landed and self.settings.highlight_crits and (value == sides)
        crit_fail = landed and self.settings.highlight_crits and (value == 1)

        if crit_success:
            base_hex, edge_hex, text_color = "#f2d16b", PALETTE["gold"], "#4a2e00"
        elif crit_fail:
            base_hex, edge_hex, text_color = "#d98282", PALETTE["crimson"], PALETTE["crimson_dark"]
        elif rolling:
            base_hex, edge_hex, text_color = theme["base"], PALETTE["gold_dim"], theme["text"]
        else:
            base_hex, edge_hex, text_color = theme["base"], theme["edge"], theme["text"]

        # Collect visible faces
        visible_faces: List[Tuple[float, int, List[int], float, Tuple[float, float]]] = []
        for f_idx, face in enumerate(faces):
            p0, p1, p2 = rotated[face[0]], rotated[face[1]], rotated[face[2]]
            ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx

            fcx = sum(rotated[idx][0] for idx in face) / len(face)
            fcy = sum(rotated[idx][1] for idx in face) / len(face)
            fcz = sum(rotated[idx][2] for idx in face) / len(face)
            if nx * (-fcx) + ny * (-fcy) + nz * (3.6 - fcz) <= 0:
                continue

            nn = _norm3((nx, ny, nz))
            lambert = max(0.0, nn[0] * LIGHT_NORM[0] + nn[1] * LIGHT_NORM[1] + nn[2] * LIGHT_NORM[2])
            intensity = 0.42 + 0.68 * lambert
            proj_cx = sum(projected[idx][0] for idx in face) / len(face)
            proj_cy = sum(projected[idx][1] for idx in face) / len(face)
            visible_faces.append((fcz, f_idx, face, intensity, (proj_cx, proj_cy)))

        visible_faces.sort(key=lambda item: item[0])
        front_f_idx = visible_faces[-1][1] if visible_faces else None
        face_numbers = assign_face_numbers(len(faces), sides, value, front_f_idx)

        face_font_size = max(8, int(scale * (0.28 if len(faces) <= 8 else 0.21)))
        front_font_size = max(11, int(scale * 0.38))

        for _z, f_idx, face, intensity, (fc_x, fc_y) in visible_faces:
            pts: List[float] = []
            for idx in face:
                pts.extend((projected[idx][0], projected[idx][1]))

            is_front = (f_idx == front_f_idx)
            fill_col = shade_hex_color(base_hex, intensity + (0.08 if is_front else 0.0))
            self.canvas.create_polygon(
                pts,
                fill=fill_col,
                outline=edge_hex,
                width=self.settings.edge_width,
                joinstyle=tk.ROUND,
            )

            # For d2 coin, only label the 2 cap faces (indices 0, 1) — skip thin rim quads
            if sides == 2 and f_idx >= 2:
                continue

            if self.settings.show_all_face_numbers or is_front:
                f_size = front_font_size if is_front else face_font_size
                f_color = text_color if is_front else shade_hex_color(text_color, 0.85)
                self.canvas.create_text(
                    fc_x,
                    fc_y,
                    text=str(face_numbers[f_idx]),
                    font=(self._serif, f_size, "bold"),
                    fill=f_color,
                )

    def _draw_arena_decor(self) -> None:
        cx, cy = self.canvas_w / 2.0, (self.canvas_h - 18) / 2.0
        for r, dash in ((112, (4, 6)), (124, None)):
            self.canvas.create_oval(
                cx - r, cy - r, cx + r, cy + r,
                outline=PALETTE["oak_light"] if dash is None else PALETTE["gold_dim"],
                width=1, dash=dash,
            )
        pad = 12
        for rx, ry in (
            (pad, pad), (self.canvas_w - pad, pad),
            (pad, self.canvas_h - pad), (self.canvas_w - pad, self.canvas_h - pad),
        ):
            self.canvas.create_oval(
                rx - 4, ry - 4, rx + 4, ry + 4,
                fill=PALETTE["gold_dim"], outline=PALETTE["gold"], width=1,
            )

    def _append_history(self, record: MultiRollRecord) -> None:
        idx = len(self.roller.multi_history)
        if record.count == 1 and record.modifier == 0:
            val = record.values[0]
            tag = " [КРИТ!]" if val == record.sides else (" [ПРОВАЛ]" if val == 1 else "")
            line = f"#{idx:03d} [{record.timestamp}] {record.label:<5} -> {val:>3}{tag}"
        else:
            vals = ",".join(str(v) for v in record.values)
            line = f"#{idx:03d} [{record.timestamp}] {record.label:<6} [{vals}] = {record.total}"

        self.history_list.insert(0, line)
        if self.settings.highlight_crits:
            if record.crit_successes > 0 and record.crit_fails == 0:
                self.history_list.itemconfig(0, fg=PALETTE["crit_gold"])
            elif record.crit_fails > 0 and record.crit_successes == 0:
                self.history_list.itemconfig(0, fg=PALETTE["crit_red"])

    def _refresh_stats(self) -> None:
        s = self.roller.stats()
        if s.total_rolls == 0:
            self.stats_var.set(
                "Костей брошено: 0  |  Среднее: —\nМин: —  |  Макс: —  |  Криты: 0/0"
            )
            return
        self.stats_var.set(
            f"Костей брошено: {s.total_rolls}  |  Среднее: {s.average:.2f}\n"
            f"Мин: {s.minimum}  |  Макс: {s.maximum}  |  Криты (усп/прв): {s.crit_successes}/{s.crit_fails}"
        )

    def _clear_history(self) -> None:
        self.roller.clear_history()
        self.history_list.delete(0, tk.END)
        self._refresh_stats()


def main() -> None:
    root = tk.Tk()
    MedievalDiceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
