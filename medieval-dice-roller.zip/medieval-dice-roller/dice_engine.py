"""Pure logic for the Fantasy-Medieval Dice Roller (d2 - d100)."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Tuple

MIN_SIDES = 2
MAX_SIDES = 100
PRESET_SIDES = (2, 4, 6, 8, 10, 12, 20, 100)


@dataclass(frozen=True)
class RollRecord:
    """Represents a single die roll outcome."""

    sides: int
    value: int
    timestamp: str
    is_crit_success: bool
    is_crit_fail: bool

    @property
    def label(self) -> str:
        return f"d{self.sides}"


@dataclass
class RollStats:
    """Aggregated statistics for a session of rolls."""

    total_rolls: int = 0
    average: float = 0.0
    minimum: Optional[int] = None
    maximum: Optional[int] = None
    crit_successes: int = 0
    crit_fails: int = 0


class DiceRoller:
    """Handles validated die rolls (2-100 sides) and roll history."""

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._rng = rng or random.SystemRandom()
        self._history: List[RollRecord] = []

    @staticmethod
    def validate_sides(sides: int) -> int:
        if not isinstance(sides, int) or isinstance(sides, bool):
            raise ValueError(f"Количество граней должно быть целым числом, получено: {sides!r}")
        if sides < MIN_SIDES or sides > MAX_SIDES:
            raise ValueError(
                f"Количество граней должно быть от {MIN_SIDES} до {MAX_SIDES}, получено: {sides}"
            )
        return sides

    def roll(self, sides: int) -> RollRecord:
        """Roll a die with `sides` faces (2..100) and record the result."""
        sides = self.validate_sides(sides)
        value = self._rng.randint(1, sides)
        record = RollRecord(
            sides=sides,
            value=value,
            timestamp=datetime.now().strftime("%H:%M:%S"),
            is_crit_success=(value == sides),
            is_crit_fail=(value == 1),
        )
        self._history.append(record)
        return record

    def preview_value(self, sides: int) -> int:
        """Return a transient random face value for rolling animation without recording."""
        sides = self.validate_sides(sides)
        return self._rng.randint(1, sides)

    @property
    def history(self) -> List[RollRecord]:
        return list(self._history)

    def clear_history(self) -> None:
        self._history.clear()

    def stats(self) -> RollStats:
        if not self._history:
            return RollStats()
        values = [r.value for r in self._history]
        return RollStats(
            total_rolls=len(values),
            average=sum(values) / len(values),
            minimum=min(values),
            maximum=max(values),
            crit_successes=sum(1 for r in self._history if r.is_crit_success),
            crit_fails=sum(1 for r in self._history if r.is_crit_fail),
        )


def compute_die_polygon(
    sides: int,
    cx: float,
    cy: float,
    radius: float,
    angle_offset_deg: float = 0.0,
) -> List[Tuple[float, float]]:
    """Compute 2D polygon vertices for rendering a die on a Canvas.

    Classic polyhedra get iconic silhouettes; higher/custom side counts
    map smoothly to a multi-faceted medallion.
    """
    DiceRoller.validate_sides(sides)

    if sides == 2:
        # Coin / medallion approximated as a 24-gon
        vertices = 24
        start_deg = -90.0
    elif sides in (3, 4):
        vertices = 3
        start_deg = -90.0
    elif sides == 6:
        vertices = 4
        start_deg = -45.0
    elif sides == 8:
        # Diamond / octahedron silhouette
        vertices = 4
        start_deg = -90.0
    elif sides in (10, 12):
        vertices = 5
        start_deg = -90.0
    elif sides == 20:
        vertices = 6
        start_deg = -90.0
    else:
        # Custom N: map to 7..16 vertices so it stays crisp and legible
        vertices = min(16, max(7, sides if sides <= 12 else 8 + (sides % 5)))
        start_deg = -90.0

    points: List[Tuple[float, float]] = []
    step = 360.0 / vertices
    for i in range(vertices):
        rad = math.radians(start_deg + angle_offset_deg + i * step)
        points.append((cx + radius * math.cos(rad), cy + radius * math.sin(rad)))
    return points


def get_roll_flavor_text(record: RollRecord) -> Tuple[str, str]:
    """Return (title, subtitle) in medieval fantasy style for a roll result."""
    if record.is_crit_success:
        return (
            "КРИТИЧЕСКИЙ УСПЕХ!",
            f"Боги благоволят! Выпал максимум ({record.value}) на {record.label}.",
        )
    if record.is_crit_fail:
        return (
            "КРИТИЧЕСКИЙ ПРОВАЛ!",
            f"Тёмная фортуна отвернулась: единица на {record.label}.",
        )

    ratio = record.value / record.sides
    if ratio >= 0.75:
        return ("Славный бросок", f"Могучий результат {record.value} из {record.sides}.")
    if ratio >= 0.4:
        return ("Верная рука", f"Выпало {record.value} на {record.label}.")
    return ("Скромный жребий", f"Кость показала {record.value} на {record.label}.")
