"""Pure logic, settings, and 3D polyhedron engine for the Fantasy-Medieval Dice Roller (d2 - d100)."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Tuple

MIN_SIDES = 2
MAX_SIDES = 100
MIN_DICE_COUNT = 1
MAX_DICE_COUNT = 6
MIN_MODIFIER = -20
MAX_MODIFIER = 20
PRESET_SIDES = (2, 4, 6, 8, 10, 12, 20, 100)

Vec3 = Tuple[float, float, float]
Mesh3D = Tuple[List[Vec3], List[List[int]]]

DIE_THEMES: Dict[str, Dict[str, str]] = {
    "Пергамент и Золото": {
        "base": "#efe0c1",
        "edge": "#d4af37",
        "text": "#24170e",
        "crit_text": "#4a2e00",
    },
    "Королевский Рубин": {
        "base": "#9e2424",
        "edge": "#e0b84c",
        "text": "#f7edd7",
        "crit_text": "#fff3b0",
    },
    "Изумруд Друида": {
        "base": "#265c3e",
        "edge": "#cfa844",
        "text": "#f5ecd7",
        "crit_text": "#ffe680",
    },
    "Обсидиан и Серебро": {
        "base": "#2c2f36",
        "edge": "#c0c7d1",
        "text": "#eef2f7",
        "crit_text": "#ffd966",
    },
}


@dataclass
class AppSettings:
    """Configurable settings for dice rolling, 3D animation, and appearance."""

    dice_count: int = 1
    modifier: int = 0
    animate: bool = True
    anim_duration_ms: int = 650
    anim_fps: int = 30
    spin_speed: float = 1.2
    bounce_height: int = 24
    show_all_face_numbers: bool = True
    show_shadow: bool = True
    edge_width: int = 2
    highlight_crits: bool = True
    theme_name: str = "Пергамент и Золото"

    def normalized(self) -> "AppSettings":
        return AppSettings(
            dice_count=max(MIN_DICE_COUNT, min(MAX_DICE_COUNT, int(self.dice_count))),
            modifier=max(MIN_MODIFIER, min(MAX_MODIFIER, int(self.modifier))),
            animate=bool(self.animate),
            anim_duration_ms=max(100, min(3000, int(self.anim_duration_ms))),
            anim_fps=max(15, min(60, int(self.anim_fps))),
            spin_speed=max(0.3, min(3.0, float(self.spin_speed))),
            bounce_height=max(0, min(40, int(self.bounce_height))),
            show_all_face_numbers=bool(self.show_all_face_numbers),
            show_shadow=bool(self.show_shadow),
            edge_width=max(1, min(4, int(self.edge_width))),
            highlight_crits=bool(self.highlight_crits),
            theme_name=self.theme_name if self.theme_name in DIE_THEMES else "Пергамент и Золото",
        )


@dataclass(frozen=True)
class RollRecord:
    """Represents a single die roll outcome."""

    sides: int
    value: int
    timestamp: str
    is_crit_success: bool
    is_crit_fail: bool

    @property
    def label(self) -> str:
        return f"d{self.sides}"


@dataclass(frozen=True)
class MultiRollRecord:
    """Represents a simultaneous roll of 1..6 dice with optional modifier."""

    sides: int
    values: Tuple[int, ...]
    modifier: int
    timestamp: str

    @property
    def count(self) -> int:
        return len(self.values)

    @property
    def raw_sum(self) -> int:
        return sum(self.values)

    @property
    def total(self) -> int:
        return self.raw_sum + self.modifier

    @property
    def crit_successes(self) -> int:
        return sum(1 for v in self.values if v == self.sides)

    @property
    def crit_fails(self) -> int:
        return sum(1 for v in self.values if v == 1)

    @property
    def label(self) -> str:
        mod = f"{self.modifier:+d}" if self.modifier != 0 else ""
        prefix = f"{self.count}" if self.count > 1 else ""
        return f"{prefix}d{self.sides}{mod}"


@dataclass
class RollStats:
    """Aggregated statistics for a session of rolls (per individual die rolled)."""

    total_rolls: int = 0
    average: float = 0.0
    minimum: Optional[int] = None
    maximum: Optional[int] = None
    crit_successes: int = 0
    crit_fails: int = 0


class DiceRoller:
    """Handles validated die rolls (2-100 sides, 1-6 dice) and roll history."""

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._rng = rng or random.SystemRandom()
        self._history: List[RollRecord] = []
        self._multi_history: List[MultiRollRecord] = []

    @staticmethod
    def validate_sides(sides: int) -> int:
        if not isinstance(sides, int) or isinstance(sides, bool):
            raise ValueError(f"Количество граней должно быть целым числом, получено: {sides!r}")
        if sides < MIN_SIDES or sides > MAX_SIDES:
            raise ValueError(
                f"Количество граней должно быть от {MIN_SIDES} до {MAX_SIDES}, получено: {sides}"
            )
        return sides

    @staticmethod
    def validate_count(count: int) -> int:
        if not isinstance(count, int) or isinstance(count, bool):
            raise ValueError(f"Количество костей должно быть целым числом, получено: {count!r}")
        if count < MIN_DICE_COUNT or count > MAX_DICE_COUNT:
            raise ValueError(
                f"Количество костей должно быть от {MIN_DICE_COUNT} до {MAX_DICE_COUNT}, получено: {count}"
            )
        return count

    def roll(self, sides: int) -> RollRecord:
        """Roll a single die with `sides` faces (2..100) and record the result."""
        sides = self.validate_sides(sides)
        value = self._rng.randint(1, sides)
        ts = datetime.now().strftime("%H:%M:%S")
        record = RollRecord(
            sides=sides,
            value=value,
            timestamp=ts,
            is_crit_success=(value == sides),
            is_crit_fail=(value == 1),
        )
        self._history.append(record)
        self._multi_history.append(
            MultiRollRecord(sides=sides, values=(value,), modifier=0, timestamp=ts)
        )
        return record

    def roll_many(self, sides: int, count: int, modifier: int = 0) -> MultiRollRecord:
        """Roll `count` dice simultaneously (1..6) with `sides` faces (2..100)."""
        sides = self.validate_sides(sides)
        count = self.validate_count(count)
        ts = datetime.now().strftime("%H:%M:%S")
        values = tuple(self._rng.randint(1, sides) for _ in range(count))
        for val in values:
            self._history.append(
                RollRecord(
                    sides=sides,
                    value=val,
                    timestamp=ts,
                    is_crit_success=(val == sides),
                    is_crit_fail=(val == 1),
                )
            )
        multi = MultiRollRecord(sides=sides, values=values, modifier=modifier, timestamp=ts)
        self._multi_history.append(multi)
        return multi

    def preview_value(self, sides: int) -> int:
        """Return a transient random face value for rolling animation without recording."""
        sides = self.validate_sides(sides)
        return self._rng.randint(1, sides)

    @property
    def history(self) -> List[RollRecord]:
        return list(self._history)

    @property
    def multi_history(self) -> List[MultiRollRecord]:
        return list(self._multi_history)

    def clear_history(self) -> None:
        self._history.clear()
        self._multi_history.clear()

    def stats(self) -> RollStats:
        if not self._history:
            return RollStats()
        values = [r.value for r in self._history]
        return RollStats(
            total_rolls=len(values),
            average=sum(values) / len(values),
            minimum=min(values),
            maximum=max(values),
            crit_successes=sum(1 for r in self._history if r.is_crit_success),
            crit_fails=sum(1 for r in self._history if r.is_crit_fail),
        )


# ---------------------------------------------------------------------------
# 3D Vector & Mesh Math
# ---------------------------------------------------------------------------

def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a: Vec3, b: Vec3) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross(a: Vec3, b: Vec3) -> Vec3:
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _normalize_vertices(verts: List[Vec3]) -> List[Vec3]:
    if not verts:
        return verts
    max_r = max(math.sqrt(x * x + y * y + z * z) for x, y, z in verts)
    if max_r < 1e-9:
        return verts
    return [(x / max_r, y / max_r, z / max_r) for x, y, z in verts]


def _ensure_outward_winding(verts: List[Vec3], faces: List[List[int]]) -> List[List[int]]:
    """Ensure every convex face has outward-pointing normal (CCW when viewed from outside)."""
    fixed: List[List[int]] = []
    for face in faces:
        if len(face) < 3:
            continue
        p0, p1, p2 = verts[face[0]], verts[face[1]], verts[face[2]]
        normal = _cross(_sub(p1, p0), _sub(p2, p0))
        cx = sum(verts[i][0] for i in face) / len(face)
        cy = sum(verts[i][1] for i in face) / len(face)
        cz = sum(verts[i][2] for i in face) / len(face)
        if _dot(normal, (cx, cy, cz)) < 0:
            fixed.append(list(reversed(face)))
        else:
            fixed.append(list(face))
    return fixed


def _build_cylinder_coin(segments: int = 18, half_h: float = 0.16) -> Mesh3D:
    verts: List[Vec3] = []
    for z in (half_h, -half_h):
        for i in range(segments):
            ang = 2.0 * math.pi * i / segments
            verts.append((math.cos(ang), math.sin(ang), z))
    faces: List[List[int]] = [
        list(range(segments)),
        list(range(segments, 2 * segments)),
    ]
    for i in range(segments):
        nxt = (i + 1) % segments
        faces.append([i, nxt, segments + nxt, segments + i])
    return _normalize_vertices(verts), _ensure_outward_winding(verts, faces)


def _build_tetrahedron() -> Mesh3D:
    verts: List[Vec3] = [
        (1.0, 1.0, 1.0),
        (1.0, -1.0, -1.0),
        (-1.0, 1.0, -1.0),
        (-1.0, -1.0, 1.0),
    ]
    faces = [
        [0, 1, 2],
        [0, 3, 1],
        [0, 2, 3],
        [1, 3, 2],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_cube() -> Mesh3D:
    verts: List[Vec3] = [
        (-1, -1, 1), (1, -1, 1), (1, 1, 1), (-1, 1, 1),
        (-1, -1, -1), (1, -1, -1), (1, 1, -1), (-1, 1, -1),
    ]
    faces = [
        [0, 1, 2, 3],
        [5, 4, 7, 6],
        [4, 0, 3, 7],
        [1, 5, 6, 2],
        [3, 2, 6, 7],
        [4, 5, 1, 0],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_octahedron() -> Mesh3D:
    verts: List[Vec3] = [
        (0, 0, 1), (0, 0, -1),
        (1, 0, 0), (-1, 0, 0),
        (0, 1, 0), (0, -1, 0),
    ]
    faces = [
        [0, 2, 4], [0, 4, 3], [0, 3, 5], [0, 5, 2],
        [1, 4, 2], [1, 3, 4], [1, 5, 3], [1, 2, 5],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_trapezohedron(n_sides: int = 5) -> Mesh3D:
    """Build an N-gonal trapezohedron (2*n_sides kite faces). n=5 -> authentic d10."""
    verts: List[Vec3] = [
        (0.0, 1.15, 0.0),
        (0.0, -1.15, 0.0),
    ]
    ring_h = 0.22
    for i in range(n_sides):
        ang = 2.0 * math.pi * i / n_sides
        verts.append((math.cos(ang), ring_h, math.sin(ang)))
    for i in range(n_sides):
        ang = 2.0 * math.pi * (i + 0.5) / n_sides
        verts.append((math.cos(ang), -ring_h, math.sin(ang)))

    faces: List[List[int]] = []
    for i in range(n_sides):
        u0 = 2 + i
        u1 = 2 + (i + 1) % n_sides
        l0 = 2 + n_sides + i
        l_prev = 2 + n_sides + (i - 1) % n_sides
        faces.append([0, u0, l0, u1])
        faces.append([1, l0, u0, l_prev])

    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_dodecahedron() -> Mesh3D:
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    inv = 1.0 / phi
    verts: List[Vec3] = [
        (-1, -1, -1), (-1, -1, 1), (-1, 1, -1), (-1, 1, 1),
        (1, -1, -1), (1, -1, 1), (1, 1, -1), (1, 1, 1),
        (0, -inv, -phi), (0, -inv, phi), (0, inv, -phi), (0, inv, phi),
        (-inv, -phi, 0), (-inv, phi, 0), (inv, -phi, 0), (inv, phi, 0),
        (-phi, 0, -inv), (-phi, 0, inv), (phi, 0, -inv), (phi, 0, inv),
    ]
    faces = [
        [3, 11, 9, 1, 17],
        [3, 17, 16, 2, 13],
        [3, 13, 15, 7, 11],
        [7, 15, 6, 18, 19],
        [7, 19, 5, 9, 11],
        [5, 19, 18, 4, 14],
        [5, 14, 12, 1, 9],
        [1, 12, 0, 16, 17],
        [0, 12, 14, 4, 8],
        [0, 8, 10, 2, 16],
        [2, 10, 6, 15, 13],
        [4, 18, 6, 10, 8],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_icosahedron() -> Mesh3D:
    phi = (1.0 + math.sqrt(5.0)) / 2.0
    verts: List[Vec3] = [
        (-1, phi, 0), (1, phi, 0), (-1, -phi, 0), (1, -phi, 0),
        (0, -1, phi), (0, 1, phi), (0, -1, -phi), (0, 1, -phi),
        (phi, 0, -1), (phi, 0, 1), (-phi, 0, -1), (-phi, 0, 1),
    ]
    faces = [
        [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
        [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
        [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
        [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
    ]
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def _build_crystal_bipyramid(ring_sides: int) -> Mesh3D:
    """Build a faceted 3D bipyramid / gemstone for custom N-sided dice."""
    verts: List[Vec3] = [(0.0, 1.05, 0.0), (0.0, -1.05, 0.0)]
    for i in range(ring_sides):
        ang = 2.0 * math.pi * i / ring_sides
        verts.append((math.cos(ang), 0.0, math.sin(ang)))
    faces: List[List[int]] = []
    for i in range(ring_sides):
        c0 = 2 + i
        c1 = 2 + (i + 1) % ring_sides
        faces.append([0, c0, c1])
        faces.append([1, c1, c0])
    verts = _normalize_vertices(verts)
    return verts, _ensure_outward_winding(verts, faces)


def build_die_mesh(sides: int) -> Mesh3D:
    """Return a 3D convex polyhedron mesh (vertices, faces) for the given die sides."""
    DiceRoller.validate_sides(sides)
    if sides == 2:
        return _build_cylinder_coin()
    if sides in (3, 4):
        return _build_tetrahedron()
    if sides == 6:
        return _build_cube()
    if sides == 8:
        return _build_octahedron()
    if sides in (10, 100):
        return _build_trapezohedron(5)
    if sides == 12:
        return _build_dodecahedron()
    if sides == 20:
        return _build_icosahedron()
    ring = max(5, min(14, (sides + 1) // 2))
    return _build_crystal_bipyramid(ring)


def assign_face_numbers(
    num_faces: int,
    sides: int,
    target_value: int,
    front_face_idx: Optional[int] = None,
) -> List[int]:
    """Assign a number in 1..sides to every 3D face, placing `target_value` on `front_face_idx`."""
    if num_faces <= 0:
        return []
    DiceRoller.validate_sides(sides)
    target_value = max(1, min(sides, int(target_value)))

    # Build a pool of distinct values across 1..sides
    if sides <= num_faces:
        pool = [((i % sides) + 1) for i in range(num_faces)]
    else:
        step = max(1, sides // num_faces)
        pool = []
        cur = target_value
        for _ in range(num_faces):
            pool.append(cur)
            cur = ((cur - 1 + step) % sides) + 1

    if front_face_idx is not None and 0 <= front_face_idx < num_faces:
        if target_value in pool:
            existing_idx = pool.index(target_value)
            pool[existing_idx], pool[front_face_idx] = pool[front_face_idx], pool[existing_idx]
        else:
            pool[front_face_idx] = target_value

    return pool


# 3D engraved digit strokes in normalized [-0.45, 0.45] x [-0.7, 0.7] coordinates
DIGIT_STROKES: Dict[str, List[List[Tuple[float, float]]]] = {
    "0": [[(-0.35, 0.6), (0.35, 0.6), (0.4, 0.4), (0.4, -0.4), (0.35, -0.6), (-0.35, -0.6), (-0.4, -0.4), (-0.4, 0.4), (-0.35, 0.6)]],
    "1": [[(-0.18, 0.38), (0.08, 0.65), (0.08, -0.65)], [(-0.22, -0.65), (0.32, -0.65)]],
    "2": [[(-0.38, 0.42), (-0.2, 0.65), (0.25, 0.65), (0.38, 0.42), (0.38, 0.18), (-0.38, -0.65), (0.4, -0.65)]],
    "3": [[(-0.35, 0.55), (-0.1, 0.65), (0.25, 0.65), (0.38, 0.42), (0.32, 0.12), (0.0, 0.05), (0.35, -0.1), (0.38, -0.45), (0.2, -0.65), (-0.2, -0.65), (-0.38, -0.5)]],
    "4": [[(0.22, -0.65), (0.22, 0.65), (-0.4, -0.18), (0.42, -0.18)]],
    "5": [[(0.36, 0.65), (-0.32, 0.65), (-0.36, 0.1), (0.2, 0.12), (0.38, -0.1), (0.38, -0.45), (0.2, -0.65), (-0.22, -0.65), (-0.38, -0.48)]],
    "6": [[(0.32, 0.55), (0.12, 0.65), (-0.22, 0.65), (-0.38, 0.35), (-0.38, -0.42), (-0.2, -0.65), (0.22, -0.65), (0.38, -0.42), (0.38, -0.08), (0.2, 0.08), (-0.36, 0.08)]],
    "7": [[(-0.38, 0.65), (0.4, 0.65), (-0.12, -0.65)]],
    "8": [[(0.0, 0.06), (-0.32, 0.2), (-0.32, 0.5), (-0.15, 0.65), (0.15, 0.65), (0.32, 0.5), (0.32, 0.2), (0.0, 0.06), (0.36, -0.12), (0.36, -0.48), (0.18, -0.65), (-0.18, -0.65), (-0.36, -0.48), (-0.36, -0.12), (0.0, 0.06)]],
    "9": [[(0.36, -0.05), (-0.2, -0.05), (-0.38, 0.12), (-0.38, 0.45), (-0.2, 0.65), (0.2, 0.65), (0.38, 0.42), (0.38, -0.38), (0.18, -0.65), (-0.22, -0.65), (-0.34, -0.52)]],
}


def project_face_number_3d(
    value: int,
    face_center: Vec3,
    face_normal: Vec3,
    face_scale: float,
    cx: float,
    cy: float,
    scale: float,
    camera_dist: float = 3.6,
) -> List[List[Tuple[float, float]]]:
    """Project engraved 3D strokes of `value` onto a 3D face plane in perspective."""
    # Orthonormal basis (U, V) on the face plane
    ref: Vec3 = (0.0, 1.0, 0.0) if abs(face_normal[1]) < 0.9 else (0.0, 0.0, 1.0)
    u = _cross(ref, face_normal)
    u_len = math.sqrt(_dot(u, u))
    if u_len < 1e-6:
        return []
    u = (u[0] / u_len, u[1] / u_len, u[2] / u_len)
    v = _cross(face_normal, u)

    text = str(value)
    n_chars = len(text)
    char_advance = 1.05
    total_w = n_chars * char_advance
    fit = face_scale * (0.48 if n_chars == 1 else (0.36 if n_chars == 2 else 0.27))

    polylines: List[List[Tuple[float, float]]] = []
    for idx, ch in enumerate(text):
        strokes = DIGIT_STROKES.get(ch)
        if not strokes:
            continue
        x_offset = (idx + 0.5) * char_advance - total_w / 2.0
        for stroke in strokes:
            pts_2d: List[Tuple[float, float]] = []
            for lx, ly in stroke:
                du = (lx + x_offset) * fit
                dv = ly * fit
                p3d: Vec3 = (
                    face_center[0] + u[0] * du + v[0] * dv + face_normal[0] * 0.015,
                    face_center[1] + u[1] * du + v[1] * dv + face_normal[1] * 0.015,
                    face_center[2] + u[2] * du + v[2] * dv + face_normal[2] * 0.015,
                )
                px, py, _ = project_point(p3d, cx, cy, scale=scale, camera_dist=camera_dist)
                pts_2d.append((px, py))
            polylines.append(pts_2d)
    return polylines


def rotate_point(pt: Vec3, rx: float, ry: float, rz: float) -> Vec3:
    """Rotate a 3D point by Euler angles (radians) around X, Y, Z."""
    x, y, z = pt

    cx, sx = math.cos(rx), math.sin(rx)
    y, z = y * cx - z * sx, y * sx + z * cx

    cy, sy = math.cos(ry), math.sin(ry)
    x, z = x * cy + z * sy, -x * sy + z * cy

    cz, sz = math.cos(rz), math.sin(rz)
    x, y = x * cz - y * sz, x * sz + y * cz

    return (x, y, z)


def project_point(
    pt: Vec3,
    cx: float,
    cy: float,
    scale: float,
    camera_dist: float = 3.6,
) -> Tuple[float, float, float]:
    """Perspective-project a 3D point to 2D canvas coordinates + depth."""
    x, y, z = pt
    denom = max(0.5, camera_dist - z)
    factor = (scale * camera_dist) / denom
    return (cx + x * factor, cy - y * factor, z)


def shade_hex_color(base_hex: str, intensity: float) -> str:
    """Modulate a #RRGGBB color by lighting intensity (0.25 .. 1.15)."""
    base = base_hex.lstrip("#")
    r = int(base[0:2], 16)
    g = int(base[2:4], 16)
    b = int(base[4:6], 16)
    factor = max(0.25, min(1.15, intensity))
    nr = min(255, max(0, int(r * factor)))
    ng = min(255, max(0, int(g * factor)))
    nb = min(255, max(0, int(b * factor)))
    return f"#{nr:02x}{ng:02x}{nb:02x}"


def compute_die_polygon(
    sides: int,
    cx: float,
    cy: float,
    radius: float,
    angle_offset_deg: float = 0.0,
) -> List[Tuple[float, float]]:
    """2D fallback polygon vertices for compatibility."""
    DiceRoller.validate_sides(sides)
    vertices = 24 if sides == 2 else (3 if sides in (3, 4) else (4 if sides in (6, 8) else 6))
    points: List[Tuple[float, float]] = []
    step = 360.0 / vertices
    for i in range(vertices):
        rad = math.radians(-90.0 + angle_offset_deg + i * step)
        points.append((cx + radius * math.cos(rad), cy + radius * math.sin(rad)))
    return points


def get_roll_flavor_text(record: RollRecord) -> Tuple[str, str]:
    """Return (title, subtitle) in medieval fantasy style for a roll result."""
    if record.is_crit_success:
        return (
            "КРИТИЧЕСКИЙ УСПЕХ!",
            f"Боги благоволят! Выпал максимум ({record.value}) на {record.label}.",
        )
    if record.is_crit_fail:
        return (
            "КРИТИЧЕСКИЙ ПРОВАЛ!",
            f"Тёмная фортуна отвернулась: единица на {record.label}.",
        )

    ratio = record.value / record.sides
    if ratio >= 0.75:
        return ("Славный бросок", f"Могучий результат {record.value} из {record.sides}.")
    if ratio >= 0.4:
        return ("Верная рука", f"Выпало {record.value} на {record.label}.")
    return ("Скромный жребий", f"Кость показала {record.value} на {record.label}.")


def get_multi_roll_flavor_text(record: MultiRollRecord) -> Tuple[str, str]:
    """Return (title, subtitle) for 1..6 simultaneous dice with optional modifier."""
    if record.count == 1 and record.modifier == 0:
        single = RollRecord(
            sides=record.sides,
            value=record.values[0],
            timestamp=record.timestamp,
            is_crit_success=(record.values[0] == record.sides),
            is_crit_fail=(record.values[0] == 1),
        )
        return get_roll_flavor_text(single)

    parts = " + ".join(str(v) for v in record.values)
    mod_str = f" {record.modifier:+d}" if record.modifier != 0 else ""
    if record.crit_successes > 0 and record.crit_fails == 0:
        title = f"КРИТИЧЕСКИЙ УСПЕХ! Итог: {record.total}"
    elif record.crit_fails > 0 and record.crit_successes == 0:
        title = f"Тёмный жребий! Итог: {record.total}"
    else:
        title = f"Итог броска: {record.total}"

    subtitle = f"{record.label}: [{parts}]{mod_str} = {record.total}"
    return (title, subtitle)
